interface Props {
  status: 'firing' | 'resolved' | 'running' | 'completed' | 'inconclusive' | 'scan_failed' | 'unscoped';
  size?: 'sm' | 'md';
}

const CONFIG = {
  firing: { label: 'FIRING', cls: 'bg-amber-500/15 text-amber-400 border-amber-500/30', dot: 'bg-amber-400 animate-pulse' },
  resolved: { label: 'RESOLVED', cls: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', dot: 'bg-emerald-400' },
  running: { label: 'RUNNING', cls: 'bg-sky-500/15 text-sky-400 border-sky-500/30', dot: 'bg-sky-400 animate-pulse' },
  completed: { label: 'COMPLETED', cls: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', dot: 'bg-emerald-400' },
  inconclusive: { label: 'INCONCLUSIVE', cls: 'bg-orange-500/15 text-orange-400 border-orange-500/30', dot: 'bg-orange-400' },
  scan_failed: { label: 'SCAN FAILED', cls: 'bg-red-500/15 text-red-400 border-red-500/30', dot: 'bg-red-400' },
  unscoped: { label: 'UNSCOPED', cls: 'bg-slate-500/15 text-slate-400 border-slate-500/30', dot: 'bg-slate-400' },
};

export default function StatusBadge({ status, size = 'sm' }: Props) {
  const c = CONFIG[status];
  const textSize = size === 'md' ? 'text-xs' : 'text-[11px]';
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded border font-mono font-medium tracking-wide ${textSize} ${c.cls}`}>
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${c.dot}`} />
      {c.label}
    </span>
  );
}
