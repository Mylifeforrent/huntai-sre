import { ReactNode } from 'react';
import { useApp } from '../App';

interface Props {
  children: ReactNode;
}

const NAV_ITEMS_ALERT = [
  { label: '告警', icon: '◈', path: '#alerts', group: undefined as string | undefined },
];

const NAV_ITEMS_SRE = [
  { label: '告警', icon: '◈', path: '#alerts' },
  { label: '扫描', icon: '⊙', path: '#scan' },
  { label: '数据源', icon: '◎', path: '#settings-datasources', group: 'settings' },
  { label: 'Skill 映射', icon: '◇', path: '#settings-skills', group: 'settings' },
  { label: '团队绑定', icon: '◑', path: '#settings-bindings', group: 'settings' },
  { label: '额度与成本闸', icon: '◐', path: '#settings-quota', group: 'settings' },
];

function roleLabel(role: string) {
  if (role === 'sre') return 'SRE';
  if (role === 'breakglass') return '本地管理员';
  return '开发 on-call';
}

function roleColor(role: string) {
  if (role === 'sre') return 'text-sky-400';
  if (role === 'breakglass') return 'text-red-400';
  return 'text-slate-400';
}

export default function AppShell({ children }: Props) {
  const { role, llmEnabled, navigate, phase2Enabled } = useApp();
  // Phase 2: dev can see Scan tab (read-only)
  const devItems = phase2Enabled
    ? [{ label: '告警', icon: '◈', path: '#alerts', group: undefined }, { label: '扫描', icon: '⊙', path: '#scan', group: undefined }]
    : NAV_ITEMS_ALERT;
  const items = role === 'dev' ? devItems : NAV_ITEMS_SRE;
  const currentHash = window.location.hash;

  const mainItems = items.filter(i => !i.group);
  const settingsItems = items.filter(i => i.group === 'settings');

  return (
    <div className="flex h-screen overflow-hidden bg-[#0f1117]">
      {/* Sidebar */}
      <nav className="w-56 flex-shrink-0 flex flex-col border-r border-slate-800 bg-[#0d0f18]">
        {/* Logo */}
        <div className="px-4 py-5 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-blue-400 text-lg font-mono font-bold">H</span>
            <span className="text-slate-100 font-semibold text-sm tracking-wide">HuntAI SRE</span>
          </div>
        </div>

        {/* Main nav */}
        <div className="flex-1 py-4 overflow-y-auto">
          <div className="px-3 mb-1">
            {mainItems.map(item => (
              <a
                key={item.path}
                href={item.path}
                className={`flex items-center gap-2.5 px-3 py-2 rounded text-sm mb-0.5 transition-colors ${
                  currentHash === item.path || (item.path === '#alerts' && (currentHash === '' || currentHash === '#'))
                    ? 'bg-blue-600/20 text-blue-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <span className="text-xs opacity-70">{item.icon}</span>
                {item.label}
              </a>
            ))}
          </div>

          {settingsItems.length > 0 && (
            <div className="px-3 mt-4">
              <div className="px-3 py-1 text-[10px] font-medium tracking-widest text-slate-600 uppercase mb-1">设置</div>
              {settingsItems.map(item => (
                <a
                  key={item.path}
                  href={item.path}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded text-sm mb-0.5 transition-colors ${
                    currentHash === item.path
                      ? 'bg-blue-600/20 text-blue-400'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <span className="text-xs opacity-70">{item.icon}</span>
                  {item.label}
                </a>
              ))}
            </div>
          )}
        </div>

        {/* User area */}
        <div className="px-4 py-3 border-t border-slate-800">
          <div className="text-xs text-slate-500">Li Wei</div>
          <div className={`text-xs font-medium mt-0.5 ${roleColor(role)}`}>{roleLabel(role)}</div>
        </div>
      </nav>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Break-glass banner */}
        {role === 'breakglass' && (
          <div className="bg-red-900/30 border-b border-red-800/50 px-4 py-2 text-xs text-red-300 flex items-center gap-2">
            <span>⚠</span>
            <span>本地管理员会话 · 非日常调查账号，仅限紧急排障使用</span>
          </div>
        )}

        {/* LLM disabled banner */}
        {!llmEnabled && (
          <div className="bg-amber-900/20 border-b border-amber-800/30 px-4 py-2 text-xs text-amber-300 flex items-center gap-2">
            <span>◐</span>
            <span>AI 调查不可用（LLM 已关闭）；告警列表与规则扫描仍有效</span>
          </div>
        )}

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
