import { useState } from 'react';
import { useApp, UserRole } from '../App';

export default function DevToolbar() {
  const [open, setOpen] = useState(false);
  const { role, setRole, llmEnabled, setLlmEnabled, orgGateClosed, setOrgGateClosed,
    userDailyQuota, setUserDailyQuota, loggedIn, setLoggedIn, navigate,
    phase2Enabled, setPhase2Enabled } = useApp();

  return (
    <div className="fixed bottom-4 right-4 z-[100] font-mono">
      {open && (
        <div className="mb-2 bg-[#0d0f18] border border-slate-700 rounded-lg shadow-2xl p-4 w-64 text-xs">
          <div className="text-slate-400 font-semibold mb-3 text-[10px] tracking-widest uppercase">原型演示工具栏</div>

          {/* Role */}
          <div className="mb-3">
            <div className="text-slate-500 mb-1">角色</div>
            <div className="flex gap-1">
              {(['sre', 'dev', 'breakglass'] as UserRole[]).map(r => (
                <button
                  key={r}
                  onClick={() => { setRole(r); if (!loggedIn) { setLoggedIn(true); navigate('#alerts'); } }}
                  className={`flex-1 py-1 rounded text-[10px] transition-colors ${
                    role === r ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {r === 'sre' ? 'SRE' : r === 'dev' ? 'Dev' : 'Admin'}
                </button>
              ))}
            </div>
          </div>

          {/* Login state */}
          <div className="mb-3">
            <div className="text-slate-500 mb-1">会话</div>
            <div className="flex gap-1">
              <button
                onClick={() => { setLoggedIn(true); navigate('#alerts'); }}
                className={`flex-1 py-1 rounded text-[10px] transition-colors ${loggedIn ? 'bg-emerald-700 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
              >
                已登录
              </button>
              <button
                onClick={() => { setLoggedIn(false); navigate('#login'); }}
                className={`flex-1 py-1 rounded text-[10px] transition-colors ${!loggedIn ? 'bg-slate-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
              >
                未登录
              </button>
            </div>
          </div>

          {/* LLM */}
          <div className="mb-3">
            <div className="text-slate-500 mb-1">LLM</div>
            <div className="flex gap-1">
              <button onClick={() => setLlmEnabled(true)} className={`flex-1 py-1 rounded text-[10px] transition-colors ${llmEnabled ? 'bg-emerald-700 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>开启</button>
              <button onClick={() => setLlmEnabled(false)} className={`flex-1 py-1 rounded text-[10px] transition-colors ${!llmEnabled ? 'bg-amber-700 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>关闭</button>
            </div>
          </div>

          {/* Org gate */}
          <div className="mb-3">
            <div className="text-slate-500 mb-1">组织调查闸</div>
            <div className="flex gap-1">
              <button onClick={() => setOrgGateClosed(false)} className={`flex-1 py-1 rounded text-[10px] transition-colors ${!orgGateClosed ? 'bg-emerald-700 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>开放</button>
              <button onClick={() => setOrgGateClosed(true)} className={`flex-1 py-1 rounded text-[10px] transition-colors ${orgGateClosed ? 'bg-red-700 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>关闭</button>
            </div>
          </div>

          {/* Quota */}
          <div className="mb-3">
            <div className="text-slate-500 mb-1">今日剩余调查次数: {userDailyQuota}/30</div>
            <div className="flex gap-1">
              <button onClick={() => setUserDailyQuota(27)} className="flex-1 py-1 rounded text-[10px] bg-slate-800 text-slate-400 hover:bg-slate-700">重置(27)</button>
              <button onClick={() => setUserDailyQuota(0)} className="flex-1 py-1 rounded text-[10px] bg-slate-800 text-slate-400 hover:bg-slate-700">用尽(0)</button>
            </div>
          </div>

          {/* Phase 2 toggle */}
          <div className="mb-3 pb-3 border-b border-slate-800">
            <div className="text-slate-500 mb-1 flex items-center gap-1.5">
              <span>二期功能</span>
              <span className="px-1.5 py-0.5 bg-violet-900/40 border border-violet-700/40 text-violet-400 text-[9px] rounded">〔二期〕</span>
            </div>
            <div className="flex gap-1">
              <button
                onClick={() => setPhase2Enabled(false)}
                className={`flex-1 py-1 rounded text-[10px] transition-colors ${!phase2Enabled ? 'bg-slate-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
              >
                一期
              </button>
              <button
                onClick={() => setPhase2Enabled(true)}
                className={`flex-1 py-1 rounded text-[10px] transition-colors ${phase2Enabled ? 'bg-violet-700 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
              >
                二期
              </button>
            </div>
            {phase2Enabled && (
              <p className="mt-1 text-[9px] text-violet-400 leading-relaxed">
                自动调查 · Loki · 写操作审批 · 定时扫描 · Dev扫描只读视图
              </p>
            )}
          </div>

          {/* Quick nav */}
          <div>
            <div className="text-slate-500 mb-1">快速跳转</div>
            <div className="grid grid-cols-2 gap-1">
              {[
                ['#alerts', '告警列表'],
                ['#alert?id=alert-001', '告警详情'],
                ['#investigation?id=inv-001', '调查(完成)'],
                ['#investigation?id=inv-002', '调查(不确定)'],
                ['#investigation?id=inv-004', '自动调查〔二〕'],
                ['#scan', '集群扫描'],
                ['#scan-result?id=scan-001', '扫描结果'],
                ['#scan-result?id=scan-005', '定时扫描〔二〕'],
                ['#deep-link-miss?cluster_id=prod-us-east-1&fingerprint=unknown123', '深链未命中'],
                ['#settings-quota', '额度闸'],
              ].map(([path, label]) => (
                <button
                  key={path}
                  onClick={() => navigate(path)}
                  className="py-1 px-2 rounded text-[10px] bg-slate-800 text-slate-400 hover:bg-slate-700 text-left truncate"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
      <button
        onClick={() => setOpen(o => !o)}
        className={`text-white text-xs px-3 py-2 rounded-full shadow-lg font-mono transition-colors ${phase2Enabled ? 'bg-violet-600 hover:bg-violet-500' : 'bg-blue-600 hover:bg-blue-500'}`}
      >
        {open ? '✕ 工具栏' : phase2Enabled ? '⚙ 演示〔二期〕' : '⚙ 演示'}
      </button>
    </div>
  );
}
