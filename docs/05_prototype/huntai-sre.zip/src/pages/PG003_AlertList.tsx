import { useState, useMemo } from 'react';
import { useApp } from '../App';
import { MOCK_ALERTS } from '../mock/alerts';
import { MOCK_CLUSTERS } from '../mock/clusters';
import StatusBadge from '../components/StatusBadge';

const SEVERITY_DOT: Record<string, string> = {
  critical: 'bg-red-500',
  warning: 'bg-amber-400',
  info: 'bg-sky-400',
};

export default function PG003_AlertList() {
  const { role, navigate, phase2Enabled } = useApp();
  const [loading] = useState(false);
  const [loadError] = useState(false);
  const [clusterFilter, setClusterFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'firing' | 'resolved'>('firing');

  const visibleAlerts = useMemo(() => {
    return MOCK_ALERTS.filter(a => {
      if (role === 'dev' && a.unscoped) return false;
      if (role === 'dev' && a.team !== 'payments' && a.team !== 'order-service') return false;
      if (clusterFilter !== 'all' && a.cluster_id !== clusterFilter) return false;
      if (statusFilter !== 'all' && a.status !== statusFilter) return false;
      return true;
    });
  }, [role, clusterFilter, statusFilter]);

  const allAlerts = useMemo(() => {
    return MOCK_ALERTS.filter(a => {
      if (role === 'dev' && a.unscoped) return false;
      if (role === 'dev' && a.team !== 'payments' && a.team !== 'order-service') return false;
      return true;
    });
  }, [role]);

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  };

  if (loadError) {
    return (
      <div className="p-8 flex flex-col items-center gap-4">
        <div className="text-slate-500 text-4xl">✗</div>
        <p className="text-slate-400 text-sm">告警列表加载失败</p>
        <button onClick={() => window.location.reload()} className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded text-sm text-slate-200 transition-colors">重试</button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <h1 className="text-base font-semibold text-slate-100">告警</h1>
        <div className="text-xs text-slate-500 font-mono">{allAlerts.length} 条可见告警</div>
      </div>

      <div className="px-6 py-3 border-b border-slate-800 flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-500">集群</label>
          <select
            value={clusterFilter}
            onChange={e => setClusterFilter(e.target.value)}
            className="bg-[#0f1117] border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-300 focus:outline-none focus:border-blue-500/50"
          >
            <option value="all">全部集群</option>
            {MOCK_CLUSTERS.map(c => (
              <option key={c.id} value={c.cluster_id}>{c.cluster_id}</option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-1 bg-[#0f1117] border border-slate-700 rounded p-0.5">
          {(['all', 'firing', 'resolved'] as const).map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={`px-3 py-1 rounded text-xs transition-colors ${statusFilter === s ? 'bg-slate-700 text-slate-100' : 'text-slate-500 hover:text-slate-300'}`}>
              {s === 'all' ? '全部' : s === 'firing' ? 'Firing' : 'Resolved'}
            </button>
          ))}
        </div>
        {(clusterFilter !== 'all' || statusFilter !== 'firing') && (
          <button onClick={() => { setClusterFilter('all'); setStatusFilter('firing'); }}
            className="text-xs text-slate-500 hover:text-slate-300 transition-colors underline">
            清除筛选
          </button>
        )}
      </div>

      <div className="flex-1 overflow-auto">
        {loading ? <SkeletonRows /> : visibleAlerts.length === 0 ? (
          <EmptyState hasBaseData={allAlerts.length > 0} />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] text-slate-500 uppercase tracking-wide">
                <th className="px-6 py-3 text-left font-medium">状态</th>
                <th className="px-4 py-3 text-left font-medium">告警名称</th>
                <th className="px-4 py-3 text-left font-medium">severity</th>
                <th className="px-4 py-3 text-left font-medium">集群</th>
                <th className="px-4 py-3 text-left font-medium">范围</th>
                {phase2Enabled && (
                  <th className="px-4 py-3 text-left font-medium">
                    <span className="flex items-center gap-1">严重度 <Phase2Badge /></span>
                  </th>
                )}
                <th className="px-4 py-3 text-left font-medium">接收时间</th>
              </tr>
            </thead>
            <tbody>
              {visibleAlerts.map(alert => (
                <tr key={alert.id} onClick={() => navigate(`#alert?id=${alert.id}`)}
                  className="border-b border-slate-800/50 hover:bg-slate-800/30 cursor-pointer transition-colors group">
                  <td className="px-6 py-3.5"><StatusBadge status={alert.status} /></td>
                  <td className="px-4 py-3.5">
                    <span className="font-mono text-slate-200 text-xs group-hover:text-blue-400 transition-colors">{alert.alertname}</span>
                  </td>
                  <td className="px-4 py-3.5">
                    {alert.severity ? (
                      <span className="flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${SEVERITY_DOT[alert.severity] ?? 'bg-slate-500'}`} />
                        <span className="font-mono text-[11px] text-slate-400">{alert.severity}</span>
                      </span>
                    ) : <span className="text-slate-600 text-xs">—</span>}
                  </td>
                  <td className="px-4 py-3.5"><span className="font-mono text-xs text-slate-400">{alert.cluster_id}</span></td>
                  <td className="px-4 py-3.5">
                    {alert.unscoped ? <StatusBadge status="unscoped" /> : (
                      <span className="text-xs text-slate-400">
                        {alert.team && <span className="bg-slate-800 px-1.5 py-0.5 rounded mr-1 text-slate-300">{alert.team}</span>}
                        {alert.namespace && <span className="text-slate-500">{alert.namespace}</span>}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3.5"><span className="text-xs text-slate-500 font-mono">{formatTime(alert.receivedAt)}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function EmptyState({ hasBaseData }: { hasBaseData: boolean }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <div className="text-slate-700 text-4xl">◈</div>
      {hasBaseData ? (
        <><p className="text-slate-400 text-sm">当前筛选无结果</p><p className="text-slate-600 text-xs">尝试调整集群或状态筛选</p></>
      ) : (
        <><p className="text-slate-400 text-sm">暂无可见告警</p><p className="text-slate-600 text-xs">Alertmanager webhook 尚未接入，或当前角色可见范围内暂无告警</p></>
      )}
    </div>
  );
}

function SkeletonRows() {
  return (
    <div className="divide-y divide-slate-800/50">
      {[1, 2, 3, 4, 5].map(i => (
        <div key={i} className="flex items-center gap-4 px-6 py-4 animate-pulse">
          <div className="h-5 w-16 bg-slate-800 rounded" />
          <div className="h-4 w-48 bg-slate-800 rounded" />
          <div className="h-4 w-16 bg-slate-800 rounded" />
          <div className="h-4 w-32 bg-slate-800 rounded" />
        </div>
      ))}
    </div>
  );
}
