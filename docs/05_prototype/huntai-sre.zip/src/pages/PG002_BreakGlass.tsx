import { useState } from 'react';
import { useApp } from '../App';

export default function PG002_BreakGlass() {
  const { setLoggedIn, setRole, navigate } = useApp();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [state, setState] = useState<'default' | 'submitting' | 'error'>('default');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    setState('submitting');
    setTimeout(() => {
      // Demo: any non-empty credentials succeed for prototype
      if (username && password.length >= 4) {
        setRole('breakglass');
        setLoggedIn(true);
        navigate('#alerts');
      } else {
        setState('error');
      }
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#0f1117] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-red-900/20 border border-red-800/30 mb-4">
            <span className="text-red-400 text-xl">⚠</span>
          </div>
          <h1 className="text-xl font-semibold text-slate-100">紧急本地管理员登录</h1>
          <p className="text-sm text-red-400 mt-1 font-medium">不用于日常调查</p>
        </div>

        <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg p-6">
          <div className="mb-5 px-3 py-2.5 bg-red-900/20 border border-red-800/30 rounded text-xs text-red-300 leading-relaxed">
            此账号仅限紧急排障场景使用。日常调查请使用 OIDC 账号登录。所有操作将写入审计日志。
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {state === 'error' && (
              <div className="px-3 py-2 bg-red-900/30 border border-red-800/50 rounded text-sm text-red-300">
                凭证错误，请重试
              </div>
            )}

            <div>
              <label className="block text-xs text-slate-400 mb-1.5">用户名</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                disabled={state === 'submitting'}
                className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50 disabled:opacity-50"
                placeholder="管理员账号"
                autoComplete="off"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5">密码</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                disabled={state === 'submitting'}
                className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50 disabled:opacity-50"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={state === 'submitting' || !username || !password}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded bg-red-700 hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors"
            >
              {state === 'submitting' ? (
                <>
                  <Spinner />
                  验证中…
                </>
              ) : '提交'}
            </button>
          </form>
        </div>

        <div className="mt-4 text-center">
          <a href="#login" className="text-xs text-slate-600 hover:text-slate-500 transition-colors">
            ← 返回 OIDC 登录
          </a>
        </div>
      </div>
    </div>
  );
}

function Spinner() {
  return (
    <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  );
}
