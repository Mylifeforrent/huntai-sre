import { useState } from 'react';
import { useApp } from '../App';
import { MOCK_USERS } from '../mock/clusters';
import ConfirmModal from '../components/ConfirmModal';

function Phase2Badge() {
  return (
    <span className="px-1.5 py-0.5 bg-violet-900/40 border border-violet-700/40 text-violet-400 text-[9px] rounded font-mono">〔二期〕</span>
  );
}

export default function PG012_QuotaGate() {
  const { orgGateClosed, setOrgGateClosed, orgTokenConfigured, setOrgTokenConfigured, orgTokenLimit, setOrgTokenLimit, phase2Enabled } = useApp();
  const [selectedUserId, setSelectedUserId] = useState('');
  const [showGraceConfirm, setShowGraceConfirm] = useState(false);
  const [showGateConfirm, setShowGateConfirm] = useState(false);
  const [pendingGateState, setPendingGateState] = useState(false);
  const [tokenInput, setTokenInput] = useState(orgTokenLimit);
  const [tokenError, setTokenError] = useState('');
  const [gracedUsers, setGracedUsers] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  const handleGrace = () => {
    if (!selectedUserId) return;
    setShowGraceConfirm(true);
  };

  const confirmGrace = () => {
    setShowGraceConfirm(false);
    setSaving(true);
    setTimeout(() => {
      setGracedUsers(prev => [...prev, selectedUserId]);
      setSaving(false);
      setSelectedUserId('');
    }, 600);
  };

  const handleToggleGate = (close: boolean) => {
    setPendingGateState(close);
    setShowGateConfirm(true);
  };

  const confirmGate = () => {
    setShowGateConfirm(false);
    setOrgGateClosed(pendingGateState);
  };

  const handleSaveToken = () => {
    setTokenError('');
    if (tokenInput !== '' && (!/^\d+$/.test(tokenInput) || parseInt(tokenInput) <= 0)) {
      setTokenError('请输入正整数，或留空表示未配置');
      return;
    }
    setOrgTokenLimit(tokenInput);
    setOrgTokenConfigured(tokenInput !== '');
  };

  const selectedUser = MOCK_USERS.find(u => u.id === selectedUserId);

  return (
    <div className="h-full flex flex-col">
      <div className="px-6 py-4 border-b border-slate-800">
        <h1 className="text-base font-semibold text-slate-100">额度与成本闸</h1>
        <p className="text-xs text-slate-500 mt-0.5">管理调查额度放行与组织 token 闸</p>
      </div>

      <div className="flex-1 overflow-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-3xl">

          {/* User quota grace */}
          <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg p-5">
            <div className="text-sm font-medium text-slate-100 mb-1">临时放行用户日调查额度</div>
            <p className="text-xs text-slate-500 mb-1">每用户每自然日最多新建 30 个调查。选择用户并临时放行。</p>
            {phase2Enabled && (
              <div className="mb-3 px-2 py-1.5 bg-violet-900/10 border border-violet-700/30 rounded flex items-center gap-2 text-[10px] text-violet-300">
                <Phase2Badge />
                <span>自动调查（trigger=auto）不计入 30 次/日额度（BR-074）</span>
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">选择用户</label>
                <select
                  value={selectedUserId}
                  onChange={e => setSelectedUserId(e.target.value)}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500/50"
                >
                  <option value="">请选择…</option>
                  {MOCK_USERS.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.email}) — 今日 {u.dailyUsed}/30
                    </option>
                  ))}
                </select>
              </div>

              {selectedUser && (
                <div className="px-3 py-2 bg-slate-800/40 rounded text-xs text-slate-400 font-mono">
                  今日已用: {selectedUser.dailyUsed}/30
                  {selectedUser.dailyUsed >= 30 && <span className="text-amber-400 ml-2">已达上限</span>}
                </div>
              )}

              {gracedUsers.includes(selectedUserId) && (
                <div className="px-3 py-2 bg-emerald-900/20 border border-emerald-800/30 rounded text-xs text-emerald-400">
                  ✓ 已放行
                </div>
              )}

              <button
                disabled={!selectedUserId || saving}
                onClick={handleGrace}
                className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-sm transition-colors"
              >
                {saving ? '放行中…' : '临时放行'}
              </button>

              <p className="text-xs text-slate-600">放行操作将写入审计日志。具体放行额度与时限待业务确认（[TBD-BIZ]）。</p>
              <div className="px-3 py-2 bg-sky-900/10 border border-sky-800/20 rounded text-xs text-sky-400">
                〔二期〕自动调查（trigger=auto）不计入该用户 30 次/天额度，由系统对 severity=critical 告警自动触发。
              </div>
            </div>
          </div>

          {/* Org gate */}
          <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg p-5">
            <div className="text-sm font-medium text-slate-100 mb-1">组织调查闸</div>
            <p className="text-xs text-slate-500 mb-2">关闭后全组织无法新建调查（BR-042）。</p>
            <p className="text-xs text-slate-600 mb-4">〔TBD-BIZ〕组织闸关闭时是否同时阻断自动调查，待业务确认。</p>

            <div className="flex items-center gap-3 mb-4">
              <div className={`w-10 h-5 rounded-full relative transition-colors cursor-pointer ${orgGateClosed ? 'bg-red-600' : 'bg-emerald-600'}`}
                onClick={() => handleToggleGate(!orgGateClosed)}>
                <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${orgGateClosed ? 'left-5' : 'left-0.5'}`} />
              </div>
              <span className={`text-sm ${orgGateClosed ? 'text-red-400' : 'text-emerald-400'}`}>
                {orgGateClosed ? '已关闭新调查' : '新调查开放'}
              </span>
            </div>

            {orgGateClosed && (
              <div className="mb-4 px-3 py-2 bg-red-900/20 border border-red-800/30 rounded text-xs text-red-300">
                当前已关闭新调查。所有用户的「调查」按钮均不可用。
              </div>
            )}

            {/* Token gate */}
            <div className="pt-4 border-t border-slate-700/40">
              <div className="text-xs text-slate-400 mb-2 font-medium">组织日 token 硬闸</div>

              {!orgTokenConfigured && (
                <div className="mb-3 px-3 py-2 bg-amber-900/20 border border-amber-800/30 rounded text-xs text-amber-300">
                  闸未配置，不得视为无限（BR-042）。新调查将在 fail-close 模式下运行。
                </div>
              )}

              <div className="flex items-center gap-2 mb-2">
                <input
                  type="text"
                  value={tokenInput}
                  onChange={e => setTokenInput(e.target.value)}
                  className="w-32 bg-[#0f1117] border border-slate-700 rounded px-3 py-1.5 text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                  placeholder="留空=未配置"
                />
                <span className="text-xs text-slate-500">tokens / 天</span>
                <button
                  onClick={handleSaveToken}
                  className="px-3 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-xs text-slate-200 transition-colors"
                >
                  保存
                </button>
              </div>
              {tokenError && <p className="text-xs text-red-400">{tokenError}</p>}
              {orgTokenConfigured && (
                <p className="text-xs text-emerald-400">✓ 已配置: {orgTokenLimit} tokens/天</p>
              )}
              <p className="mt-2 text-xs text-slate-600">默认数字 [TBD-BIZ]。空值 = 未配置，不得显示「无限制」。</p>
            </div>
          </div>

          {/* Per-user table */}
          <div className="lg:col-span-2 bg-[#1a1d27] border border-slate-700/60 rounded-lg p-5">
            <div className="text-sm font-medium text-slate-100 mb-3">用户当日调查用量</div>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700/40 text-[11px] text-slate-500 uppercase tracking-wide">
                  <th className="pb-2 text-left font-medium">姓名</th>
                  <th className="pb-2 text-left font-medium">邮箱</th>
                  <th className="pb-2 text-left font-medium">角色</th>
                  <th className="pb-2 text-left font-medium">今日用量</th>
                  <th className="pb-2 text-left font-medium">状态</th>
                </tr>
              </thead>
              <tbody>
                {MOCK_USERS.map(u => (
                  <tr key={u.id} className="border-b border-slate-700/10">
                    <td className="py-2.5 text-xs text-slate-300">{u.name}</td>
                    <td className="py-2.5 font-mono text-xs text-slate-500">{u.email}</td>
                    <td className="py-2.5">
                      <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-300">{u.role}</span>
                    </td>
                    <td className="py-2.5">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1 bg-slate-800 rounded overflow-hidden">
                          <div className={`h-full rounded ${u.dailyUsed >= 30 ? 'bg-red-500' : u.dailyUsed > 20 ? 'bg-amber-500' : 'bg-blue-500'}`}
                            style={{ width: `${(u.dailyUsed / 30) * 100}%` }} />
                        </div>
                        <span className="font-mono text-xs text-slate-400">{u.dailyUsed}/30</span>
                      </div>
                    </td>
                    <td className="py-2.5">
                      {gracedUsers.includes(u.id) && (
                        <span className="text-xs text-emerald-400">已放行</span>
                      )}
                      {u.dailyUsed >= 30 && !gracedUsers.includes(u.id) && (
                        <span className="text-xs text-amber-400">额度用尽</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showGraceConfirm && selectedUser && (
        <ConfirmModal
          title="临时放行调查额度"
          description={
            <div className="space-y-2">
              <p>将临时放行以下用户的今日调查额度（将写入审计日志）：</p>
              <div className="bg-[#0f1117] rounded px-3 py-2 font-mono text-xs text-slate-300 space-y-1">
                <div>用户: {selectedUser.name} ({selectedUser.email})</div>
                <div>今日已用: {selectedUser.dailyUsed}/30</div>
              </div>
              <p className="text-amber-400 text-xs">临时放行（具体额度与时限待业务确认 [TBD-BIZ]）</p>
            </div>
          }
          confirmLabel="确认放行"
          onConfirm={confirmGrace}
          onCancel={() => setShowGraceConfirm(false)}
        />
      )}

      {showGateConfirm && (
        <ConfirmModal
          title={pendingGateState ? '关闭组织新调查' : '开放组织新调查'}
          description={
            pendingGateState
              ? '关闭后，全组织所有用户无法新建调查，直到再次开放。此操作将写入审计日志。'
              : '开放后，符合额度条件的用户可再次发起调查。此操作将写入审计日志。'
          }
          confirmLabel={pendingGateState ? '确认关闭' : '确认开放'}
          onConfirm={confirmGate}
          onCancel={() => setShowGateConfirm(false)}
          danger={pendingGateState}
        />
      )}
    </div>
  );
}
