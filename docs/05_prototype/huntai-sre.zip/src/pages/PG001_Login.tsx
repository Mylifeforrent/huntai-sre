import { useState } from 'react';
import { useApp } from '../App';

interface Props {
  redirectTo?: string;
}

export default function PG001_Login({ redirectTo }: Props) {
  const { setLoggedIn, navigate } = useApp();
  const [state, setState] = useState<'default' | 'submitting' | 'error'>('default');

  const handleLogin = () => {
    setState('submitting');
    setTimeout(() => {
      setLoggedIn(true);
      if (redirectTo && redirectTo !== '#' && redirectTo !== '#login' && redirectTo !== '#breakglass') {
        window.location.hash = redirectTo;
      } else {
        navigate('#alerts');
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#0f1117] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-blue-600/20 border border-blue-600/30 mb-4">
            <span className="text-blue-400 font-mono font-bold text-xl">H</span>
          </div>
          <h1 className="text-xl font-semibold text-slate-100">HuntAI SRE</h1>
          <p className="text-sm text-slate-500 mt-1">可信 AI 运维层</p>
        </div>

        {/* Card */}
        <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg p-6">
          <p className="text-xs text-slate-500 text-center mb-5">禁止匿名访问，请使用公司账号登录</p>

          {state === 'error' && (
            <div className="mb-4 px-3 py-2 bg-red-900/30 border border-red-800/50 rounded text-sm text-red-300">
              登录未完成，请重试
            </div>
          )}

          <button
            disabled={state === 'submitting'}
            onClick={handleLogin}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-60 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors"
          >
            {state === 'submitting' ? (
              <>
                <Spinner />
                正在跳转至公司 IdP…
              </>
            ) : (
              <>使用公司账号登录</>
            )}
          </button>

          <div className="mt-4 text-center">
            <button
              onClick={() => setState('error')}
              className="text-xs text-slate-600 hover:text-slate-500 transition-colors"
            >
              模拟 IdP 失败
            </button>
          </div>
        </div>

        {/* Break-glass link */}
        <div className="mt-4 text-center">
          <a
            href="#breakglass"
            className="text-xs text-slate-600 hover:text-slate-500 transition-colors"
          >
            紧急管理员登录
          </a>
        </div>
      </div>
    </div>
  );
}

function Spinner() {
  return (
    <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  );
}
