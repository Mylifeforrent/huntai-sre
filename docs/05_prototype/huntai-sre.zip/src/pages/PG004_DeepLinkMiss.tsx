import { useApp } from '../App';

interface Props {
  params: Record<string, string>;
}

export default function PG004_DeepLinkMiss({ params }: Props) {
  const { navigate } = useApp();
  const { cluster_id, fingerprint } = params;
  const isBroken = !cluster_id || !fingerprint;

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] gap-6 px-4">
      <div className="text-slate-700 text-6xl font-mono">◈</div>

      <div className="text-center">
        <h2 className="text-xl font-semibold text-slate-200 mb-2">
          {isBroken ? '链接不完整' : '尚未收到 AM webhook'}
        </h2>
        <p className="text-sm text-slate-500 max-w-sm leading-relaxed">
          {isBroken
            ? '深链缺少 cluster_id 或 fingerprint 参数，无法定位告警。请检查链接是否完整。'
            : '当前参数对应的告警尚未入库。Alertmanager 可能尚未触发，或 webhook 接入配置未就绪。'}
        </p>
      </div>

      {!isBroken && (
        <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg px-5 py-4 text-sm w-full max-w-md">
          <div className="text-xs text-slate-500 uppercase tracking-wide mb-3">深链参数（只读）</div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 text-xs">cluster_id</span>
              <span className="font-mono text-xs text-slate-300">{cluster_id}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 text-xs">fingerprint</span>
              <span className="font-mono text-xs text-slate-300 truncate ml-4 max-w-xs">{fingerprint}</span>
            </div>
          </div>
        </div>
      )}

      <button
        onClick={() => navigate('#alerts')}
        className="px-4 py-2 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm transition-colors"
      >
        打开告警列表
      </button>
    </div>
  );
}
