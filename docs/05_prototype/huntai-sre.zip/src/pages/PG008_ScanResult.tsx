import { useState, type ReactNode } from 'react';
import { useApp } from '../App';
import { getScanRunById } from '../mock/scanRuns';
import StatusBadge from '../components/StatusBadge';

interface Props {
  scanId?: string;
}

const SEVERITY_CONFIG = {
  critical: { label: '严重', cls: 'text-red-400 bg-red-900/15 border-red-800/20' },
  warning: { label: '警告', cls: 'text-amber-400 bg-amber-900/15 border-amber-800/20' },
  info: { label: '信息', cls: 'text-sky-400 bg-sky-900/15 border-sky-800/20' },
};

// Dev team namespaces (prototype: hardcoded for demo)
const DEV_NAMESPACES = ['payments-prod', 'orders-prod', 'default'];

function Phase2Badge() {
  return (
    <span className="px-1.5 py-0.5 bg-violet-900/40 border border-violet-700/40 text-violet-400 text-[9px] rounded font-mono">〔二期〕</span>
  );
}

export default function PG008_ScanResult({ scanId }: Props) {
  const { navigate, role, phase2Enabled } = useApp();
  const scan = scanId ? getScanRunById(scanId) : undefined;
  const isDev = role === 'dev';

  if (!scanId || !scan) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <p className="text-slate-500 text-sm">扫描记录不存在</p>
        <button onClick={() => navigate('#scan')} className="px-4 py-2 bg-slate-700 rounded text-sm text-slate-200">返回扫描页</button>
      </div>
    );
  }

  const formatTime = (iso: string) => new Date(iso).toLocaleString('zh-CN');

  // Phase 2: dev sees only their team's namespaces
  const allFindings = scan.findings;
  const visibleFindings = (phase2Enabled && isDev)
    ? allFindings.filter(f => DEV_NAMESPACES.includes(f.namespace))
    : allFindings;
  const filteredCount = allFindings.length - visibleFindings.length;

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3">
        <button onClick={() => navigate('#scan')} className="text-slate-500 hover:text-slate-300 text-sm transition-colors">← 集群扫描</button>
        <span className="text-slate-700">/</span>
        <span className="font-mono text-slate-400 text-sm">{scan.cluster_id}</span>
        {phase2Enabled && scan.trigger === 'scheduled' && (
          <span className="flex items-center gap-1.5 px-2 py-0.5 bg-violet-900/20 border border-violet-700/30 rounded text-[10px] text-violet-300 font-mono">
            定时扫描 <Phase2Badge />
          </span>
        )}
        <div className="ml-auto">
          <StatusBadge status={scan.status} size="md" />
        </div>
      </div>

      <div className="flex-1 overflow-auto px-6 py-6">
        {/* Meta */}
        <div className="grid grid-cols-3 gap-4 mb-6 max-w-lg">
          <MetaCard label="集群" value={<span className="font-mono text-xs">{scan.cluster_id}</span>} />
          <MetaCard label="开始时间" value={<span className="font-mono text-xs">{formatTime(scan.startedAt)}</span>} />
          <MetaCard label="发现数" value={<span className="font-mono text-lg font-bold">{scan.status === 'completed' ? visibleFindings.length : '—'}</span>} />
        </div>

        {/* Phase 2: dev namespace filter notice */}
        {phase2Enabled && isDev && scan.status === 'completed' && filteredCount > 0 && (
          <div className="mb-4 px-3 py-2 bg-violet-900/10 border border-violet-700/30 rounded text-xs text-violet-300 flex items-center gap-2">
            <Phase2Badge />
            <span>已按团队 namespace 过滤 · 共 {allFindings.length} 条，显示 {visibleFindings.length} 条（其他 namespace 的 {filteredCount} 条不在您的可见范围）</span>
          </div>
        )}

        {/* scan_failed */}
        {scan.status === 'scan_failed' && (
          <div className="bg-red-900/20 border border-red-800/30 rounded-lg p-5 max-w-lg">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-red-400">✗</span>
              <span className="text-sm font-medium text-red-300">扫描失败</span>
            </div>
            <p className="text-xs text-red-400 mb-4">集群只读身份不可达，或分析器运行错误。</p>
            <button
              onClick={() => navigate('#scan')}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded text-xs text-slate-200 transition-colors"
            >
              返回重新发起扫描
            </button>
          </div>
        )}

        {/* completed + empty */}
        {scan.status === 'completed' && visibleFindings.length === 0 && (
          <div className="flex flex-col items-center py-16 gap-3">
            <div className="text-emerald-600 text-4xl">✓</div>
            <p className="text-slate-300 text-sm font-medium">
              {allFindings.length > 0 && phase2Enabled && isDev ? '您的 namespace 范围内未发现异常' : '扫描完成，未发现异常'}
            </p>
            <p className="text-slate-600 text-xs">规则分析器未命中 CrashLoop / ImagePull 等问题规则</p>
          </div>
        )}

        {/* completed + findings */}
        {scan.status === 'completed' && visibleFindings.length > 0 && (
          <div>
            <div className="text-xs text-slate-500 uppercase tracking-wide mb-3">发现列表</div>
            <div className="space-y-2">
              {visibleFindings.map(finding => {
                const sev = SEVERITY_CONFIG[finding.severity];
                return (
                  <div key={finding.id} className="bg-[#1a1d27] border border-slate-700/60 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <span className={`px-2 py-0.5 rounded border text-[11px] font-mono font-medium flex-shrink-0 ${sev.cls}`}>{sev.label}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-sm text-slate-200">{finding.rule}</span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-500 mb-2">
                          <span className="font-mono">{finding.resource}</span>
                          <span>·</span>
                          <span>{finding.namespace}</span>
                        </div>
                        <p className="text-xs text-slate-400 leading-relaxed">{finding.detail}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="mt-4 text-xs text-slate-600">Finding 为本次扫描快照，无法 ack / close。如需调查具体告警，请从告警列表手动发起。</p>
          </div>
        )}
      </div>
    </div>
  );
}

function MetaCard({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="bg-[#1a1d27] border border-slate-700/60 rounded px-4 py-3">
      <div className="text-xs text-slate-500 mb-1">{label}</div>
      <div className="text-slate-200">{value}</div>
    </div>
  );
}
