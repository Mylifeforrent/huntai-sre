import { useState } from 'react';
import { MOCK_SKILL_MAPPINGS } from '../mock/clusters';

interface SkillMapping {
  id: string;
  scope: string;
  scopeValue: string;
  gitRepo: string;
  branch: string;
}

export default function PG010_SkillMapping() {
  const [mappings, setMappings] = useState<SkillMapping[]>([...MOCK_SKILL_MAPPINGS]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ scope: '全局', scopeValue: '', gitRepo: '', branch: 'main' });
  const [formError, setFormError] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const validateGitUrl = (url: string) => {
    if (!url) return true; // empty is allowed
    return url.startsWith('https://') || url.startsWith('git@') || url.startsWith('http://');
  };

  const handleSave = () => {
    const errors: Record<string, string> = {};
    if (form.gitRepo && !validateGitUrl(form.gitRepo)) errors.gitRepo = '请输入有效的 Git URL';
    if (form.scope !== '全局' && !form.scopeValue) errors.scopeValue = '请指定范围值';
    setFormError(errors);
    if (Object.keys(errors).length) return;

    setSaving(true);
    setTimeout(() => {
      const newMapping: SkillMapping = {
        id: `sm-${Date.now()}`,
        scope: form.scope,
        scopeValue: form.scopeValue,
        gitRepo: form.gitRepo,
        branch: form.branch || 'main',
      };
      setMappings(prev => [...prev, newMapping]);
      setSaving(false);
      setShowForm(false);
      setForm({ scope: '全局', scopeValue: '', gitRepo: '', branch: 'main' });
    }, 600);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-slate-100">Skill 映射</h1>
          <p className="text-xs text-slate-500 mt-0.5">管理调查时自动加载的 SKILL.md 仓库映射</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          disabled={showForm}
          className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-sm font-medium transition-colors"
        >
          添加映射
        </button>
      </div>

      <div className="flex-1 overflow-auto px-6 py-6">
        {/* Note */}
        <div className="mb-5 px-3 py-2 bg-slate-800/40 border border-slate-700/40 rounded text-xs text-slate-400 flex items-start gap-2">
          <span className="text-slate-600">ℹ</span>
          <span>空仓库允许上线；调查发起时若仓库为空或无匹配 Skill，将提示「未加载组织约束」。不在此处编辑 SKILL.md 正文（Git 为源）。</span>
        </div>

        {/* Add form */}
        {showForm && (
          <div className="mb-5 bg-[#1a1d27] border border-blue-600/30 rounded-lg p-5 max-w-lg">
            <div className="text-sm font-medium text-slate-200 mb-4">添加 Skill 映射</div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">范围</label>
                <select
                  value={form.scope}
                  onChange={e => setForm(f => ({ ...f, scope: e.target.value }))}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500/50"
                >
                  <option value="全局">全局</option>
                  <option value="集群">集群</option>
                  <option value="team">team</option>
                </select>
              </div>
              {form.scope !== '全局' && (
                <div>
                  <label className="block text-xs text-slate-400 mb-1.5">
                    {form.scope === '集群' ? 'cluster_id' : 'team 名称'}
                  </label>
                  <input
                    value={form.scopeValue}
                    onChange={e => setForm(f => ({ ...f, scopeValue: e.target.value }))}
                    className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                    placeholder={form.scope === '集群' ? 'prod-us-east-1' : 'payments'}
                  />
                  {formError.scopeValue && <p className="mt-1 text-xs text-red-400">{formError.scopeValue}</p>}
                </div>
              )}
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Git 仓库地址（可为空）</label>
                <input
                  value={form.gitRepo}
                  onChange={e => setForm(f => ({ ...f, gitRepo: e.target.value }))}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                  placeholder="https://git.internal/org/skills.git"
                />
                {formError.gitRepo && <p className="mt-1 text-xs text-red-400">{formError.gitRepo}</p>}
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Branch</label>
                <input
                  value={form.branch}
                  onChange={e => setForm(f => ({ ...f, branch: e.target.value }))}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                  placeholder="main"
                />
              </div>
              <div className="flex gap-2">
                <button disabled={saving} onClick={handleSave} className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm transition-colors">
                  {saving ? '保存中…' : '保存'}
                </button>
                <button onClick={() => { setShowForm(false); setFormError({}); }} className="px-4 py-2 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm transition-colors">取消</button>
              </div>
            </div>
          </div>
        )}

        {/* Mappings list */}
        {mappings.length === 0 ? (
          <div className="flex flex-col items-center py-12 gap-3">
            <div className="text-slate-700 text-3xl">◇</div>
            <p className="text-slate-400 text-sm">尚无 Skill 映射</p>
            <p className="text-slate-600 text-xs">空仓库允许上线，调查时将提示「未加载组织约束」</p>
          </div>
        ) : (
          <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700/40 text-[11px] text-slate-500 uppercase tracking-wide">
                  <th className="px-4 py-3 text-left font-medium">范围</th>
                  <th className="px-4 py-3 text-left font-medium">范围值</th>
                  <th className="px-4 py-3 text-left font-medium">Git 仓库</th>
                  <th className="px-4 py-3 text-left font-medium">Branch</th>
                </tr>
              </thead>
              <tbody>
                {mappings.map(m => (
                  <tr key={m.id} className="border-b border-slate-700/20">
                    <td className="px-4 py-3">
                      <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-300">{m.scope}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs text-slate-400">{m.scopeValue || '—'}</span>
                    </td>
                    <td className="px-4 py-3">
                      {m.gitRepo ? (
                        <span className="font-mono text-xs text-slate-300 truncate block max-w-xs">{m.gitRepo}</span>
                      ) : (
                        <span className="text-xs text-slate-600 italic">空仓库（允许上线）</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs text-slate-500">{m.branch}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
