import { useState } from 'react';
import { useApp } from '../App';
import { MOCK_CLUSTERS } from '../mock/clusters';
import { MOCK_SCAN_RUNS } from '../mock/scanRuns';
import { ScanRun } from '../mock/types';
import StatusBadge from '../components/StatusBadge';
import ConfirmModal from '../components/ConfirmModal';

let scanCounter = 100;

function Phase2Badge() {
  return (
    <span className="px-1.5 py-0.5 bg-violet-900/40 border border-violet-700/40 text-violet-400 text-[9px] rounded font-mono">〔二期〕</span>
  );
}

export default function PG007_ClusterScan() {
  const { navigate, role, phase2Enabled } = useApp();
  const [selectedCluster, setSelectedCluster] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);
  const [scanRuns, setScanRuns] = useState<ScanRun[]>([...MOCK_SCAN_RUNS]);

  const isDev = role === 'dev';
  const selectedRuns = selectedCluster ? scanRuns.filter(s => s.cluster_id === selectedCluster) : scanRuns;
  const hasActiveRun = selectedCluster
    ? scanRuns.some(s => s.cluster_id === selectedCluster && s.status === 'running')
    : false;

  const handleConfirmScan = () => {
    setShowConfirm(false);
    const newId = `scan-new-${++scanCounter}`;
    const newRun: ScanRun = {
      id: newId,
      cluster_id: selectedCluster,
      status: 'running',
      trigger: 'manual',
      startedAt: new Date().toISOString(),
      findings: [],
    };
    MOCK_SCAN_RUNS.push(newRun);
    setScanRuns([...MOCK_SCAN_RUNS]);

    setTimeout(() => {
      const idx = MOCK_SCAN_RUNS.findIndex(s => s.id === newId);
      if (idx >= 0) {
        MOCK_SCAN_RUNS[idx] = {
          ...MOCK_SCAN_RUNS[idx],
          status: 'completed',
          completedAt: new Date().toISOString(),
          findings: [
            { id: `f-${Date.now()}`, rule: 'PodRestartHigh', resource: `pod/demo-pod-${Math.random().toString(36).slice(2, 6)}`, namespace: 'default', severity: 'warning', detail: 'Pod 重启次数超过阈值（5 次/小时）。' },
          ],
        };
        setScanRuns([...MOCK_SCAN_RUNS]);
      }
    }, 3000);
  };

  const formatTime = (iso: string) => new Date(iso).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });

  return (
    <div className="h-full flex flex-col">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3">
        <div>
          <h1 className="text-base font-semibold text-slate-100">集群规则扫描</h1>
          <p className="text-xs text-slate-500 mt-0.5">零 LLM · 按需整集群规则分析</p>
        </div>
        {/* Phase 2: dev sees read-only banner */}
        {phase2Enabled && isDev && (
          <div className="ml-auto flex items-center gap-2 px-3 py-1.5 bg-violet-900/10 border border-violet-700/30 rounded text-xs text-violet-300">
            <Phase2Badge />
            <span>只读视图 · 开发 on-call 仅可查看扫描结果</span>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-auto px-6 py-6">
        {/* Scan form — only for SRE/breakglass */}
        {!isDev && (
          <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg p-5 mb-6 max-w-lg">
            <div className="mb-4">
              <label className="block text-xs text-slate-400 mb-1.5">目标集群</label>
              <select
                value={selectedCluster}
                onChange={e => setSelectedCluster(e.target.value)}
                className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500/50"
              >
                <option value="">请选择集群</option>
                {MOCK_CLUSTERS.map(c => (
                  <option key={c.id} value={c.cluster_id}>{c.cluster_id}</option>
                ))}
              </select>
            </div>

            <div className="text-xs text-slate-600 mb-4">整集群扫描 · 不调用 LLM · 不覆盖单个 namespace</div>

            <button
              disabled={!selectedCluster || hasActiveRun}
              onClick={() => setShowConfirm(true)}
              className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors"
            >
              {hasActiveRun ? '扫描进行中…' : '分析该集群'}
            </button>
            {hasActiveRun && (
              <p className="mt-2 text-xs text-sky-400">该集群已有扫描正在进行，请等待完成后再发起</p>
            )}
          </div>
        )}

        {/* Dev: cluster filter for read-only view */}
        {isDev && phase2Enabled && (
          <div className="mb-4 flex items-center gap-3">
            <label className="text-xs text-slate-500">集群</label>
            <select
              value={selectedCluster}
              onChange={e => setSelectedCluster(e.target.value)}
              className="bg-[#0f1117] border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-300 focus:outline-none focus:border-blue-500/50"
            >
              <option value="">全部集群</option>
              {MOCK_CLUSTERS.map(c => (
                <option key={c.id} value={c.cluster_id}>{c.cluster_id}</option>
              ))}
            </select>
          </div>
        )}

        {/* History */}
        <div>
          <div className="text-xs text-slate-500 uppercase tracking-wide mb-3 flex items-center gap-2">
            扫描历史
            {phase2Enabled && <Phase2Badge />}
          </div>

          {selectedRuns.length === 0 ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <div className="text-slate-700 text-4xl">⊙</div>
              <p className="text-slate-400 text-sm">尚无扫描记录</p>
            </div>
          ) : (
            <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-700/40 text-[11px] text-slate-500 uppercase tracking-wide">
                    <th className="px-4 py-3 text-left font-medium">集群</th>
                    <th className="px-4 py-3 text-left font-medium">状态</th>
                    <th className="px-4 py-3 text-left font-medium">触发方式</th>
                    <th className="px-4 py-3 text-left font-medium">开始时间</th>
                    <th className="px-4 py-3 text-left font-medium">发现</th>
                    <th className="px-4 py-3 text-left font-medium"></th>
                  </tr>
                </thead>
                <tbody>
                  {selectedRuns.sort((a, b) => b.startedAt.localeCompare(a.startedAt)).map(run => (
                    <tr key={run.id} className="border-b border-slate-700/20 hover:bg-slate-800/20 transition-colors">
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs text-slate-300">{run.cluster_id}</span>
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={run.status} />
                      </td>
                      {phase2Enabled && (
                        <td className="px-4 py-3">
                          <span className={`font-mono text-[10px] px-1.5 py-0.5 rounded ${
                            run.trigger === 'scheduled'
                              ? 'bg-violet-900/30 text-violet-400 border border-violet-800/30'
                              : 'bg-slate-800 text-slate-500'
                          }`}>
                            {run.trigger === 'scheduled' ? '定时' : '手动'}
                          </span>
                        </td>
                      )}
                      <td className="px-4 py-3">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border font-mono ${
                          run.trigger === 'scheduled'
                            ? 'text-purple-400 bg-purple-900/15 border-purple-800/20'
                            : 'text-slate-500 bg-slate-800/50 border-slate-700/30'
                        }`}>
                          {run.trigger === 'scheduled' ? '定时 〔二期〕' : '手动'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs text-slate-500">{formatTime(run.startedAt)}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-xs text-slate-400">
                          {run.status === 'completed' ? `${run.findings.length} 条` : '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        {run.status !== 'running' && (
                          <button
                            onClick={() => navigate(`#scan-result?id=${run.id}`)}
                            className="text-xs text-blue-400 hover:text-blue-300 transition-colors"
                          >
                            查看结果 →
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {phase2Enabled && (
            <p className="mt-3 text-xs text-slate-600">
              〔二期〕定时扫描每 60 分钟自动执行一次（BR-078）；开发 on-call 可查看扫描结果，结果按所属 namespace 过滤。
            </p>
          )}
        </div>
      </div>

      {showConfirm && (
        <ConfirmModal
          title="分析该集群"
          description={
            <div className="space-y-2">
              <p>将对集群 <span className="font-mono text-slate-200">{selectedCluster}</span> 发起整集群规则扫描：</p>
              <ul className="space-y-1 text-slate-500">
                <li>• 零 LLM，仅运行规则分析器</li>
                <li>• 整集群范围，不支持按 namespace 筛选</li>
                <li>• 扫描结果快照不可 ack/close</li>
              </ul>
            </div>
          }
          confirmLabel="确认扫描"
          onConfirm={handleConfirmScan}
          onCancel={() => setShowConfirm(false)}
        />
      )}
    </div>
  );
}
