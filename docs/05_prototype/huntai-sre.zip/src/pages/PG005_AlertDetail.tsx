import { useState, useEffect, type ReactNode } from 'react';
import { useApp } from '../App';
import { getAlertById } from '../mock/alerts';
import { getInvestigationsByAlertId, MOCK_INVESTIGATIONS } from '../mock/investigations';
import StatusBadge from '../components/StatusBadge';
import ConfirmModal from '../components/ConfirmModal';
import { RelatedLink } from '../mock/types';

interface Props {
  alertId?: string;
}

let invCounter = 100;

const SEVERITY_DOT: Record<string, string> = {
  critical: 'text-red-400',
  warning: 'text-amber-400',
  info: 'text-sky-400',
};

export default function PG005_AlertDetail({ alertId }: Props) {
  const { role, navigate, userDailyQuota, setUserDailyQuota, orgGateClosed } = useApp();
  const [showConfirm, setShowConfirm] = useState(false);
  const [creating, setCreating] = useState(false);
  const [showLinkForm, setShowLinkForm] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [linkError, setLinkError] = useState('');
  const [copied, setCopied] = useState(false);
  const [localLinks, setLocalLinks] = useState<RelatedLink[]>([]);

  const alert = alertId ? getAlertById(alertId) : undefined;
  const investigations = alertId ? getInvestigationsByAlertId(alertId) : [];
  const autoInv = investigations.find(i => i.trigger === 'auto');
  const humanInvs = investigations.filter(i => i.trigger === 'human');

  // Write "看过" silently on mount — no toast (BR-045, IX-FB-06)
  useEffect(() => { /* silent audit event */ }, [alert]);

  if (!alertId || !alert) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <p className="text-slate-500 text-sm">告警不存在或无访问权限</p>
        <button onClick={() => navigate('#alerts')} className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded text-sm text-slate-200 transition-colors">返回列表</button>
      </div>
    );
  }

  const allLinks = [...alert.relatedLinks, ...localLinks];

  const canInvestigate = () => {
    if (orgGateClosed) return { ok: false, reason: '组织已关闭新调查' };
    if (userDailyQuota <= 0) return { ok: false, reason: '今日调查次数已用尽（需 SRE 在额度页临时放行）' };
    return { ok: true, reason: '' };
  };
  const { ok: canInv, reason: invBlockReason } = canInvestigate();

  const isCritical = alert.labels.severity === 'critical';

  const handleInvestigateConfirm = () => {
    setShowConfirm(false);
    setCreating(true);
    setTimeout(() => {
      const newId = `inv-new-${++invCounter}`;
      MOCK_INVESTIGATIONS.push({
        id: newId,
        alertId: alert.id,
        status: 'running',
        trigger: 'human',
        startedAt: new Date().toISOString(),
        skillLoaded: true,
        llmCalls: 0,
        toolCalls: 0,
        wallClockSeconds: 0,
        userId: 'user-sre-01',
        toolCallLog: [],
        claims: [],
      });
      setUserDailyQuota(userDailyQuota - 1);
      setCreating(false);
      navigate(`#investigation?id=${newId}`);
    }, 800);
  };

  const handleSaveLink = () => {
    setLinkError('');
    if (!linkUrl) { setLinkError('URL 不能为空'); return; }
    try { new URL(linkUrl); } catch { setLinkError('请输入有效的绝对 URL（含 http:// 或 https://）'); return; }
    setLocalLinks(prev => [...prev, { id: `rl-local-${Date.now()}`, url: linkUrl, label: linkUrl }]);
    setLinkUrl('');
    setShowLinkForm(false);
  };

  const copyFingerprint = () => {
    navigator.clipboard.writeText(alert.fingerprint).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const formatTime = (iso: string) => new Date(iso).toLocaleString('zh-CN');

  return (
    <div className="h-full flex flex-col">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3">
        <button onClick={() => navigate('#alerts')} className="text-slate-500 hover:text-slate-300 text-sm transition-colors">← 告警列表</button>
        <span className="text-slate-700">/</span>
        <span className="text-slate-400 text-sm font-mono truncate">{alert.alertname}</span>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-0 h-full">
          {/* Left panel */}
          <div className="lg:col-span-3 px-6 py-6 border-r border-slate-800">
            <div className="flex items-start gap-3 mb-6">
              <StatusBadge status={alert.status} size="md" />
              <h1 className="text-lg font-mono font-semibold text-slate-100 leading-tight">{alert.alertname}</h1>
              {phase2Enabled && isCritical && (
                <span className="flex-shrink-0 mt-1 px-2 py-0.5 bg-red-900/30 border border-red-800/40 text-red-400 text-[10px] font-mono rounded">
                  severity=critical
                </span>
              )}
            </div>

            {/* Alert info */}
            <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg divide-y divide-slate-700/40 mb-6">
              <InfoRow label="集群" value={<span className="font-mono text-xs text-slate-300">{alert.cluster_id}</span>} />
              <InfoRow label="命名空间" value={<span className="font-mono text-xs text-slate-300">{alert.namespace || '—'}</span>} />
              {alert.severity && (
                <InfoRow label="severity" value={
                  <span className={`font-mono text-xs font-medium ${SEVERITY_DOT[alert.severity] ?? 'text-slate-400'}`}>
                    {alert.severity}
                  </span>
                } />
              )}
              {alert.unscoped ? (
                <InfoRow label="范围" value={<StatusBadge status="unscoped" />} />
              ) : (
                <InfoRow label="团队" value={
                  <span className="flex gap-2 flex-wrap">
                    {alert.team && <span className="bg-slate-800 px-2 py-0.5 rounded text-xs text-slate-300">{alert.team}</span>}
                    {alert.owner && <span className="text-xs text-slate-400">{alert.owner}</span>}
                  </span>
                } />
              )}
              <InfoRow label="fingerprint" value={
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-slate-300">{alert.fingerprint}</span>
                  <button onClick={copyFingerprint} className="text-xs text-slate-500 hover:text-slate-300 transition-colors">
                    {copied ? '已复制 ✓' : '复制'}
                  </button>
                </div>
              } />
              <InfoRow label="接收时间" value={<span className="font-mono text-xs text-slate-300">{formatTime(alert.receivedAt)}</span>} />
              <InfoRow label="今日剩余调查" value={<span className="font-mono text-xs text-slate-300">{userDailyQuota} / 30 次（手动；自动开查不计此额度）</span>} />
            </div>

            {/* Labels */}
            <div className="mb-6">
              <div className="text-xs text-slate-500 uppercase tracking-wide mb-2">标签</div>
              <div className="flex flex-wrap gap-2">
                {Object.entries(alert.labels).map(([k, v]) => (
                  <div key={k} className="flex items-center text-xs bg-slate-800/60 border border-slate-700/40 rounded px-2 py-1">
                    <span className="text-slate-500 mr-1">{k}=</span>
                    <span className="font-mono text-slate-300">{v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Investigate actions */}
            <div className="space-y-3">
              {/* Auto-investigation CTA (phase 2) */}
              {autoInv && (
                <div className="flex items-center gap-3 px-4 py-3 bg-sky-900/10 border border-sky-800/30 rounded-lg">
                  <span className="text-sky-400 text-xs font-medium">〔二期〕自动调查</span>
                  <StatusBadge status={autoInv.status} />
                  <button
                    onClick={() => navigate(`#investigation?id=${autoInv.id}`)}
                    className="ml-auto text-xs text-sky-400 hover:text-sky-300 transition-colors"
                  >
                    打开自动调查 →
                  </button>
                </div>
              )}

              {/* Human investigation button */}
              <div className="flex items-center gap-3">
                <button
                  disabled={!canInv || creating}
                  onClick={() => setShowConfirm(true)}
                  className="px-5 py-2.5 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors flex items-center gap-2"
                >
                  {creating ? <><Spinner /> 正在创建调查…</> : '调查'}
                </button>
                {!canInv && <span className="text-xs text-amber-400">{invBlockReason}</span>}
              </div>
            </div>
          </div>

          {/* Right panel */}
          <div className="lg:col-span-2 px-6 py-6">
            {/* Investigation history — human-triggered only in Phase 2 */}
            <div className="mb-6">
              <div className="text-xs text-slate-500 uppercase tracking-wide mb-3">
                调查历史{phase2Enabled ? <span className="ml-1 normal-case text-slate-600">（人工发起）</span> : ''}
              </div>
              {humanInvestigations.length === 0 ? (
                <p className="text-xs text-slate-600">尚无调查记录</p>
              ) : (
                <div className="space-y-2">
                  {humanInvestigations.map(inv => (
                    <button
                      key={inv.id}
                      onClick={() => navigate(`#investigation?id=${inv.id}`)}
                      className="w-full flex items-center justify-between px-3 py-2.5 bg-[#1a1d27] border border-slate-700/60 rounded hover:border-slate-600 transition-colors text-left"
                    >
                      <div className="flex items-center gap-2 flex-wrap">
                        <StatusBadge status={inv.status} />
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border font-mono ${
                          inv.trigger === 'auto'
                            ? 'text-sky-400 bg-sky-900/15 border-sky-800/20'
                            : 'text-slate-500 bg-slate-800/50 border-slate-700/30'
                        }`}>
                          {inv.trigger === 'auto' ? '自动 〔二期〕' : '手动'}
                        </span>
                        <div className="font-mono text-[10px] text-slate-500 w-full mt-0.5">{new Date(inv.startedAt).toLocaleString('zh-CN')}</div>
                      </div>
                      <span className="text-slate-600 text-xs flex-shrink-0 ml-2">→</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Related Links */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="text-xs text-slate-500 uppercase tracking-wide">外部链接</div>
                <button onClick={() => setShowLinkForm(true)} className="text-xs text-blue-400 hover:text-blue-300 transition-colors">
                  + 添加链接
                </button>
              </div>
              {showLinkForm && (
                <div className="mb-3 bg-[#1a1d27] border border-slate-700/60 rounded p-3 space-y-2">
                  <input type="url" value={linkUrl} onChange={e => setLinkUrl(e.target.value)}
                    placeholder="https://grafana.internal/..."
                    className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50" />
                  {linkError && <p className="text-xs text-red-400">{linkError}</p>}
                  <p className="text-xs text-slate-600">仅用于跳转，不作为引用证据（Loki LogQL 查询结果才是〔二期〕Citation）</p>
                  <div className="flex gap-2">
                    <button onClick={handleSaveLink} className="px-3 py-1 bg-blue-600 hover:bg-blue-500 rounded text-xs text-white transition-colors">保存</button>
                    <button onClick={() => { setShowLinkForm(false); setLinkError(''); setLinkUrl(''); }}
                      className="px-3 py-1 bg-slate-700 hover:bg-slate-600 rounded text-xs text-slate-300 transition-colors">取消</button>
                  </div>
                </div>
              )}
              {allLinks.length === 0 ? (
                <p className="text-xs text-slate-600">暂无外部链接</p>
              ) : (
                <div className="space-y-1.5">
                  {allLinks.map(link => (
                    <a key={link.id} href={link.url} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 px-3 py-2 bg-[#1a1d27] border border-slate-700/60 rounded hover:border-slate-600 transition-colors group">
                      <span className="text-slate-600 text-xs">↗</span>
                      <span className="text-xs text-slate-300 group-hover:text-blue-400 transition-colors truncate">{link.label || link.url}</span>
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showConfirm && (
        <ConfirmModal
          title="发起调查"
          description={
            <div className="space-y-2">
              <p>将对此告警发起一次只读 AI 调查（trigger=human）：</p>
              <ul className="space-y-1 text-slate-500">
                <li>• 消耗今日调查额度 1 次（剩余 {userDailyQuota}/30）；自动调查不计此额度</li>
                <li>• 最长耗时 150 秒，仅使用只读工具</li>
                <li>• 不向 Alertmanager / xMatters 写入任何内容</li>
                <li>• 发起后不可取消</li>
              </ul>
            </div>
          }
          confirmLabel="确认发起调查"
          onConfirm={handleInvestigateConfirm}
          onCancel={() => setShowConfirm(false)}
        />
      )}
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between px-4 py-2.5">
      <span className="text-xs text-slate-500 flex-shrink-0 w-28">{label}</span>
      <div className="flex-1 text-right">{value}</div>
    </div>
  );
}

function Spinner() {
  return (
    <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  );
}
