import { useState, useEffect, useRef } from 'react';
import { useApp } from '../App';
import { getInvestigationById, MOCK_INVESTIGATIONS, MOCK_APPROVAL_REQUEST } from '../mock/investigations';
import { getAlertById } from '../mock/alerts';
import StatusBadge from '../components/StatusBadge';
import ConfirmModal from '../components/ConfirmModal';
import { ToolCall, Claim, Citation, WriteAction, ApprovalStatus } from '../mock/types';

interface Props {
  invId?: string;
}

const RUNNING_TOOL_STEPS = [
  { tool: 'kubectl get pod', input: 'kubectl get pod -n payments-prod -l app=payment-processor' },
  { tool: 'kubectl describe pod', input: 'kubectl describe pod payment-processor-7d9f8b-xk2p4 -n payments-prod' },
  { tool: 'prom_alerts', input: 'Prometheus 当前 firing 告警列表' },
  { tool: 'kubectl logs', input: 'kubectl logs payment-processor-7d9f8b-xk2p4 -n payments-prod --previous --tail=50' },
  { tool: 'prom_query', input: 'container_memory_working_set_bytes{namespace="payments-prod"}' },
];

function Phase2Badge() {
  return (
    <span className="px-1.5 py-0.5 bg-violet-900/40 border border-violet-700/40 text-violet-400 text-[9px] rounded font-mono">〔二期〕</span>
  );
}

export default function PG006_InvestigationDetail({ invId }: Props) {
  const { navigate, phase2Enabled, role } = useApp();
  const [selectedCitation, setSelectedCitation] = useState<{ toolCall: ToolCall; citation: Citation } | null>(null);
  const [runStep, setRunStep] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [writeActions, setWriteActions] = useState<WriteAction[]>([]);
  const [waConfirm, setWaConfirm] = useState<WriteAction | null>(null);
  const [waReject, setWaReject] = useState<WriteAction | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const inv = invId ? getInvestigationById(invId) : undefined;

  // Load writeActions from inv
  useEffect(() => {
    if (inv?.writeActions) setWriteActions([...inv.writeActions]);
  }, [invId]);

  // Simulate running investigation progression
  useEffect(() => {
    if (!inv || inv.status !== 'running') return;
    intervalRef.current = setInterval(() => {
      setRunStep(s => {
        const next = s + 1;
        if (next >= RUNNING_TOOL_STEPS.length) {
          clearInterval(intervalRef.current!);
          setIsTransitioning(true);
          setTimeout(() => {
            const idx = MOCK_INVESTIGATIONS.findIndex(i => i.id === invId);
            if (idx >= 0) {
              const completed = { ...MOCK_INVESTIGATIONS[idx] };
              completed.status = 'completed';
              completed.completedAt = new Date().toISOString();
              completed.llmCalls = 4;
              completed.toolCalls = 7;
              completed.wallClockSeconds = 108;
              completed.skillLoaded = true;
              completed.toolCallLog = [
                { id: 'rtc-1', tool: 'kubectl get pod', input: 'kubectl get pod -n payments-prod', output: 'NAME  READY  STATUS  RESTARTS\npayment-processor-7d9f8b-xk2p4  0/1  CrashLoopBackOff  14', status: 'success' },
                { id: 'rtc-2', tool: 'kubectl describe pod', input: '...', output: 'Events:\n  Warning  OOMKilling  Memory cgroup out of memory: Kill process 8821 (java) score 982', status: 'success' },
                { id: 'rtc-3', tool: 'prom_alerts', input: '...', output: '[{"alertname":"KubePodCrashLooping","namespace":"payments-prod"}]', status: 'success' },
                { id: 'rtc-4', tool: 'kubectl logs', input: '...', output: 'OutOfMemoryError: Java heap space at com.payments.BatchProcessor.dedup', status: 'success' },
                { id: 'rtc-5', tool: 'prom_query', input: '...', output: '"value": "536870912"', status: 'success' },
              ];
              completed.claims = [
                {
                  id: 'rc-1',
                  text: 'Pod payment-processor-7d9f8b-xk2p4 被 OOMKilled，累计重启 14 次。内存限制 512Mi，崩溃前堆内存 498MB/512MB。',
                  citations: [
                    { id: 'rcit-1', toolCallId: 'rtc-1', excerpt: 'CrashLoopBackOff, RESTARTS: 14' },
                    { id: 'rcit-2', toolCallId: 'rtc-2', excerpt: 'Memory cgroup out of memory: Kill process 8821 (java)' },
                  ],
                },
                {
                  id: 'rc-2',
                  text: '批处理任务同时分配 312MB 结果缓存与 178MB 去重索引（共 490MB），超出 512Mi 限制。',
                  citations: [
                    { id: 'rcit-3', toolCallId: 'rtc-4', excerpt: 'OutOfMemoryError: Java heap space at com.payments.BatchProcessor.dedup' },
                  ],
                },
              ];
              MOCK_INVESTIGATIONS[idx] = completed;
            }
            setIsTransitioning(false);
          }, 1000);
          return next;
        }
        return next;
      });
    }, 900);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [inv?.status, invId]);

  if (!invId || !inv) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <p className="text-slate-500 text-sm">调查记录不存在或已按保留策略删除</p>
        <button onClick={() => navigate('#alerts')} className="px-4 py-2 bg-slate-700 rounded text-sm text-slate-200">返回告警列表</button>
      </div>
    );
  }

  const alert = getAlertById(inv.alertId);
  const liveInv = getInvestigationById(invId)!;

  // Loki tool calls (phase 2)
  const lokiToolCalls = liveInv.toolCallLog.filter(tc => tc.isLoki);

  const inconclusiveReasonText = () => {
    switch (liveInv.inconclusiveReason) {
      case 'no_citation': return '零引用：所有工具调用均未产生有效证据，无法生成有引用的断言。';
      case 'cost_gate_llm': return `成本闸触发：LLM 调用已达上限（${liveInv.llmCalls}/8）。`;
      case 'cost_gate_tool': return `成本闸触发：只读工具调用已达上限（${liveInv.toolCalls}/12）。`;
      case 'cost_gate_time': return '成本闸触发：墙钟已达 150 秒上限。';
      default: return '调查未能产出有引用的断言。';
    }
  };

  const isRunning = liveInv.status === 'running' || isTransitioning;
  const isAutoInvestigation = liveInv.trigger === 'auto';
  const showApproval = phase2Enabled && liveInv.approvalRequest && liveInv.status === 'completed';

  const handleApprovalAction = (action: 'confirm' | 'reject') => {
    setApprovalState(prev => ({
      ...prev,
      status: action === 'confirm' ? 'confirmed' : 'rejected',
      respondedAt: new Date().toISOString(),
      respondedBy: role === 'sre' ? 'user-sre-01' : 'user-breakglass',
    }));
    setShowApprovalConfirm(null);
  };

  const handleWaConfirm = (wa: WriteAction) => {
    setWaConfirm(null);
    setWriteActions(prev => prev.map(a => a.id === wa.id
      ? { ...a, approvalStatus: 'confirmed' as ApprovalStatus, confirmedBy: 'user-sre-01', confirmedAt: new Date().toISOString() }
      : a
    ));
  };

  const handleWaReject = (wa: WriteAction) => {
    setWaReject(null);
    setWriteActions(prev => prev.map(a => a.id === wa.id
      ? { ...a, approvalStatus: 'rejected' as ApprovalStatus }
      : a
    ));
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3">
        {alert && (
          <button onClick={() => navigate(`#alert?id=${inv.alertId}`)} className="text-slate-500 hover:text-slate-300 text-sm transition-colors">← {alert.alertname}</button>
        )}
        <span className="text-slate-700">/</span>
        <span className="text-slate-400 text-sm">调查详情</span>
        {/* Trigger badge */}
        <span className={`text-[10px] px-1.5 py-0.5 rounded border font-mono ${
          liveInv.trigger === 'auto'
            ? 'text-sky-400 bg-sky-900/15 border-sky-800/20'
            : 'text-slate-500 bg-slate-800/50 border-slate-700/30'
        }`}>
          {liveInv.trigger === 'auto' ? '自动触发 〔二期〕' : '手动触发'}
        </span>
        <div className="ml-auto">
          <StatusBadge status={liveInv.status} size="md" />
        </div>
      </div>

      {/* Phase 2: Auto-investigator info */}
      {phase2Enabled && isAutoInvestigation && (
        <div className="px-6 py-2 bg-violet-900/10 border-b border-violet-800/20 flex items-center gap-2">
          <span className="text-[10px] text-slate-500">发起方：</span>
          <span className="font-mono text-[10px] text-violet-400">自动调查（不可登录账号 · system）</span>
          <span className="text-slate-600 text-[10px]">BR-071</span>
        </div>
      )}

      <div className="flex-1 overflow-auto">
        <div className="grid grid-cols-1 lg:grid-cols-5 h-full">
          {/* Left: Status + Claims + WriteActions */}
          <div className="lg:col-span-3 px-6 py-6 border-r border-slate-800">
            {/* Status headline */}
            {isRunning && (
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-1">
                  <StatusBadge status="running" size="md" />
                  <span className="text-slate-300 text-sm">正在执行只读调查…</span>
                </div>
                <p className="text-xs text-slate-600">调查由系统自动执行，无需手动操作。最长耗时 150 秒。</p>
              </div>
            )}

            {liveInv.status === 'completed' && !isRunning && (
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-2">
                  <StatusBadge status="completed" size="md" />
                  <span className="text-slate-100 text-sm font-medium">调查完成（含引用）</span>
                </div>
                <p className="text-xs text-slate-500">以下每条断言均附有服务端铸造的引用证据。</p>
              </div>
            )}

            {liveInv.status === 'inconclusive' && (
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-2">
                  <StatusBadge status="inconclusive" size="md" />
                  <span className="text-orange-400 text-sm font-medium">调查结束 · 证据不足</span>
                </div>
                <div className="px-3 py-2.5 bg-orange-900/20 border border-orange-800/30 rounded text-xs text-orange-300 leading-relaxed">
                  {inconclusiveReasonText()}
                </div>
              </div>
            )}

            {/* Skill banner */}
            <div className={`mb-5 px-3 py-2 rounded text-xs flex items-center gap-2 ${
              liveInv.skillLoaded
                ? 'bg-emerald-900/15 border border-emerald-800/20 text-emerald-400'
                : 'bg-amber-900/15 border border-amber-800/20 text-amber-400'
            }`}>
              <span>{liveInv.skillLoaded ? '◇' : '◈'}</span>
              <span>{liveInv.skillLoaded ? '已加载组织约束（Skill）' : '未加载组织约束'}</span>
            </div>

            {/* Phase 2: ApprovalRequest card */}
            {showApproval && (
              <div className="mb-6 bg-[#1a1d27] border border-amber-700/40 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-amber-400 text-xs">✦</span>
                  <span className="text-xs font-medium text-amber-300">写操作审批</span>
                  <Phase2Badge />
                  <span className={`ml-auto font-mono text-[10px] px-1.5 py-0.5 rounded ${
                    approvalState.status === 'pending' ? 'bg-amber-900/30 text-amber-400' :
                    approvalState.status === 'confirmed' ? 'bg-emerald-900/30 text-emerald-400' :
                    approvalState.status === 'rejected' ? 'bg-red-900/30 text-red-400' :
                    'bg-slate-800 text-slate-500'
                  }`}>
                    {approvalState.status === 'pending' ? '待审批' :
                     approvalState.status === 'confirmed' ? '已批准' :
                     approvalState.status === 'rejected' ? '已拒绝' : '已作废'}
                  </span>
                </div>

                <div className="bg-[#0f1117] rounded px-3 py-2.5 mb-3 font-mono text-xs space-y-1">
                  <div className="text-slate-500">操作类型: <span className="text-slate-300">{liveInv.approvalRequest!.action.type}</span></div>
                  <div className="text-slate-500">目标资源: <span className="text-slate-300">{liveInv.approvalRequest!.action.target}</span></div>
                  <div className="text-slate-500">命名空间: <span className="text-slate-300">{liveInv.approvalRequest!.action.namespace}</span></div>
                  <div className="text-slate-400 pt-1">{liveInv.approvalRequest!.action.detail}</div>
                </div>

                {approvalState.status === 'pending' && (role === 'sre' || role === 'breakglass') && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowApprovalConfirm('confirm')}
                      className="px-3 py-1.5 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-xs transition-colors"
                    >
                      批准执行
                    </button>
                    <button
                      onClick={() => setShowApprovalConfirm('reject')}
                      className="px-3 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs transition-colors"
                    >
                      拒绝
                    </button>
                    <span className="text-[10px] text-slate-600 self-center ml-1">BR-082 · 仅 restart / scale</span>
                  </div>
                )}

                {approvalState.status !== 'pending' && (
                  <div className="text-xs text-slate-500">
                    {approvalState.respondedAt && (
                      <span>{new Date(approvalState.respondedAt).toLocaleString('zh-CN')} 由 {approvalState.respondedBy} 处理</span>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Claims */}
            {liveInv.status === 'completed' && liveInv.claims.length > 0 && (
              <div className="mb-6">
                <div className="text-xs text-slate-500 uppercase tracking-wide mb-3">因果断言</div>
                <div className="space-y-4">
                  {liveInv.claims.map((claim, ci) => (
                    <ClaimCard
                      key={claim.id}
                      claim={claim}
                      index={ci + 1}
                      toolCallLog={liveInv.toolCallLog}
                      onCitationClick={(tc, cit) => setSelectedCitation({ toolCall: tc, citation: cit })}
                      phase2Enabled={phase2Enabled}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* WriteAction cards (phase 2) */}
            {writeActions.length > 0 && (
              <div className="mb-6">
                <div className="text-xs text-slate-500 uppercase tracking-wide mb-3">〔二期〕写操作审批</div>
                <div className="space-y-3">
                  {writeActions.map(wa => (
                    <WriteActionCard
                      key={wa.id}
                      wa={wa}
                      onConfirm={() => setWaConfirm(wa)}
                      onReject={() => setWaReject(wa)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Running tool timeline */}
            {isRunning && (
              <div>
                <div className="text-xs text-slate-500 uppercase tracking-wide mb-3">工具调用时间线</div>
                <div className="space-y-2">
                  {RUNNING_TOOL_STEPS.slice(0, Math.min(runStep + 1, RUNNING_TOOL_STEPS.length)).map((step, i) => (
                    <div key={i} className={`flex items-start gap-3 px-3 py-2.5 rounded border ${
                      i < runStep ? 'bg-emerald-900/10 border-emerald-800/20' : 'bg-sky-900/10 border-sky-800/20'
                    }`}>
                      <span className={`text-xs mt-0.5 ${i < runStep ? 'text-emerald-400' : 'text-sky-400'}`}>
                        {i < runStep ? '✓' : '◌'}
                      </span>
                      <div>
                        <div className="font-mono text-xs text-slate-300">{step.tool}</div>
                        <div className="font-mono text-[10px] text-slate-500 mt-0.5 truncate max-w-xs">{step.input}</div>
                      </div>
                    </div>
                  ))}
                  {isTransitioning && (
                    <div className="flex items-center gap-2 px-3 py-2 text-xs text-slate-500">
                      <Spinner /> 正在生成断言…
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Inconclusive tool log */}
            {liveInv.status === 'inconclusive' && liveInv.toolCallLog.length > 0 && (
              <div>
                <div className="text-xs text-slate-500 uppercase tracking-wide mb-3">工具调用记录</div>
                <div className="space-y-2">
                  {liveInv.toolCallLog.map(tc => (
                    <div key={tc.id} className={`px-3 py-2.5 rounded border text-xs ${
                      tc.status === 'failed'
                        ? 'bg-red-900/10 border-red-800/20'
                        : 'bg-slate-800/30 border-slate-700/30'
                    }`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={tc.status === 'failed' ? 'text-red-400' : 'text-slate-400'}>
                          {tc.status === 'failed' ? '✗ 失败' : '✓'}
                        </span>
                        <span className="font-mono text-slate-300">{tc.tool}</span>
                        {tc.isLoki && <span className="text-purple-400 text-[10px]">〔Loki〕</span>}
                        {tc.truncated && <span className="text-amber-400 text-[10px] ml-1">[已截断]</span>}
                        {phase2Enabled && tc.isLoki && (
                          <span className="text-violet-400 text-[10px] ml-1 px-1.5 py-0.5 bg-violet-900/20 border border-violet-800/30 rounded">Loki LogQL 〔二〕</span>
                        )}
                      </div>
                      <div className="font-mono text-[10px] text-slate-500">{tc.input}</div>
                      {tc.status === 'failed' && (
                        <div className="mt-1 text-red-400 text-[10px]">此次失败不可被引用为证据</div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Completed tool log (with Loki highlight in Phase 2) */}
            {liveInv.status === 'completed' && phase2Enabled && liveInv.toolCallLog.some(tc => tc.isLoki) && (
              <div className="mt-6">
                <div className="text-xs text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-2">
                  Loki 日志工具 <Phase2Badge />
                </div>
                <div className="space-y-2">
                  {liveInv.toolCallLog.filter(tc => tc.isLoki).map(tc => (
                    <div key={tc.id} className="bg-violet-900/10 border border-violet-700/30 rounded px-3 py-2.5">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-violet-400 text-xs">⊛ loki_query</span>
                        <span className="text-[10px] text-slate-600">LogQL</span>
                      </div>
                      <div className="font-mono text-[10px] text-violet-300/60 mb-1 truncate">{tc.input}</div>
                      <pre className="font-mono text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">{tc.output}</pre>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right: Cost gate + Loki citations + external links + Citation viewer */}
          <div className="lg:col-span-2 px-6 py-6">
            {/* Initiator info in Phase 2 */}
            {phase2Enabled && (
              <div className="mb-5 bg-[#1a1d27] border border-slate-700/60 rounded-lg px-4 py-3">
                <div className="text-[10px] text-slate-500 mb-2 uppercase tracking-wide flex items-center gap-2">
                  调查元信息 <Phase2Badge />
                </div>
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">触发方式</span>
                    <span className={`font-mono ${isAutoInvestigation ? 'text-violet-400' : 'text-slate-300'}`}>
                      {isAutoInvestigation ? 'auto' : 'human'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">发起人</span>
                    <span className="font-mono text-slate-300">
                      {isAutoInvestigation ? 'system（自动）' : liveInv.userId}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Cost gate counters */}
            <div className="mb-6">
              <div className="text-xs text-slate-500 uppercase tracking-wide mb-3">成本闸用量</div>
              <div className="space-y-2">
                <GateCounter label="LLM 调用" used={isRunning ? Math.floor(runStep * 0.8) : liveInv.llmCalls} limit={8} />
                <GateCounter label="工具调用" used={isRunning ? runStep : liveInv.toolCalls} limit={12} />
                <GateCounter label="墙钟" used={isRunning ? runStep * 18 : liveInv.wallClockSeconds} limit={150} unit="s" />
              </div>
            </div>

            {/* Loki Citations zone (phase 2) */}
            {lokiToolCalls.length > 0 && (
              <div className="mb-6">
                <div className="text-xs text-slate-500 uppercase tracking-wide mb-2">
                  〔二期〕Loki 查询结果 <span className="text-purple-400 font-normal normal-case">（可作为 Citation）</span>
                </div>
                <div className="space-y-2">
                  {lokiToolCalls.map(tc => (
                    <button
                      key={tc.id}
                      onClick={() => setSelectedCitation({ toolCall: tc, citation: { id: `loki-view-${tc.id}`, toolCallId: tc.id, excerpt: tc.output?.slice(0, 120) ?? '' } })}
                      className="w-full text-left px-3 py-2.5 bg-purple-900/10 border border-purple-800/20 rounded hover:bg-purple-900/20 transition-colors"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-purple-400 text-[10px] font-mono">loki_logql</span>
                        <span className="text-slate-600 text-[10px]">点击查看原始输出</span>
                      </div>
                      <div className="font-mono text-[10px] text-purple-300/70 truncate">{tc.input}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* RelatedLinks */}
            {alert && alert.relatedLinks.length > 0 && (
              <div className="mb-6">
                <div className="text-xs text-slate-500 uppercase tracking-wide mb-2">外部链接</div>
                <div className="space-y-1.5">
                  {alert.relatedLinks.map(link => (
                    <a
                      key={link.id}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-3 py-2 bg-[#1a1d27] border border-slate-700/60 rounded hover:border-slate-600 transition-colors text-xs"
                    >
                      <span className="text-slate-600">↗</span>
                      <span className="text-slate-400 truncate">{link.label}</span>
                      <span className="text-slate-600 text-[10px] ml-auto flex-shrink-0">外部链接，不是证据</span>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Citation panel */}
            {selectedCitation && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs text-slate-500 uppercase tracking-wide">
                    {selectedCitation.toolCall.isLoki ? 'Loki 查询结果（只读副本）' : '引用证据（只读副本）'}
                  </div>
                  <button onClick={() => setSelectedCitation(null)} className="text-xs text-slate-600 hover:text-slate-400">✕</button>
                </div>
                <div className="bg-[#0f1117] border border-slate-700/60 rounded-lg p-4">
                  <div className="font-mono text-[10px] text-slate-500 mb-2 flex items-center gap-2">
                    <span>{selectedCitation.toolCall.tool}</span>
                    {selectedCitation.toolCall.isLoki && <span className="text-purple-400">〔Loki〕</span>}
                    {selectedCitation.toolCall.truncated && <span className="text-amber-400">[已截断]</span>}
                    {phase2Enabled && selectedCitation.toolCall.isLoki && (
                      <span className="text-violet-400 text-[10px] px-1 py-0.5 bg-violet-900/20 border border-violet-800/30 rounded">Loki LogQL</span>
                    )}
                  </div>
                  <div className="font-mono text-[10px] text-slate-600 mb-3 border-b border-slate-700/40 pb-2">{selectedCitation.toolCall.input}</div>
                  <pre className="font-mono text-xs text-slate-300 whitespace-pre-wrap break-all leading-relaxed max-h-64 overflow-auto">
                    {selectedCitation.toolCall.output}
                  </pre>
                  {selectedCitation.citation.excerpt && (
                    <div className="mt-3 pt-2 border-t border-slate-700/40">
                      <div className="text-[10px] text-slate-500 mb-1">引用片段</div>
                      <div className="font-mono text-xs text-amber-300 bg-amber-900/10 px-2 py-1 rounded border border-amber-800/20">
                        {selectedCitation.citation.excerpt}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {!selectedCitation && liveInv.status === 'completed' && (
              <p className="text-xs text-slate-600">点击断言下的引用徽章查看工具调用原始副本</p>
            )}
          </div>
        </div>
      </div>

      {/* WriteAction confirm modal */}
      {waConfirm && (
        <ConfirmModal
          title="确认写操作"
          danger
          description={
            <div className="space-y-2">
              <p>以下命令将在集群中执行（写操作不可撤销）：</p>
              <pre className="font-mono text-xs bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-amber-300 whitespace-pre-wrap break-all">
                {waConfirm.preview}
              </pre>
              <p className="text-slate-500 text-xs">确认后，由系统以 WriteIdentity 执行。</p>
            </div>
          }
          confirmLabel="确认执行"
          onConfirm={() => handleWaConfirm(waConfirm)}
          onCancel={() => setWaConfirm(null)}
        />
      )}

      {waReject && (
        <ConfirmModal
          title="拒绝写操作"
          description={
            <div className="space-y-1">
              <p>拒绝后，该写操作将变为 rejected 状态，不可恢复。</p>
              <pre className="font-mono text-xs bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-slate-400 mt-2 whitespace-pre-wrap">
                {waReject.preview}
              </pre>
            </div>
          }
          confirmLabel="确认拒绝"
          onConfirm={() => handleWaReject(waReject)}
          onCancel={() => setWaReject(null)}
        />
      )}
    </div>
  );
}

function WriteActionCard({ wa, onConfirm, onReject }: { wa: WriteAction; onConfirm: () => void; onReject: () => void }) {
  const statusMeta: Record<ApprovalStatus, { label: string; color: string }> = {
    pending: { label: '待审批', color: 'text-amber-400 bg-amber-900/15 border-amber-800/30' },
    confirmed: { label: '已确认', color: 'text-emerald-400 bg-emerald-900/15 border-emerald-800/30' },
    rejected: { label: '已拒绝', color: 'text-red-400 bg-red-900/15 border-red-800/30' },
    void: { label: '已作废', color: 'text-slate-500 bg-slate-800/30 border-slate-700/30' },
  };
  const meta = statusMeta[wa.approvalStatus];

  return (
    <div className={`rounded-lg border p-4 ${meta.color}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono uppercase">{wa.verb}</span>
          <span className="text-xs">{wa.target}</span>
          <span className="text-[10px] text-slate-500 font-mono">{wa.namespace}</span>
        </div>
        <span className="text-[10px] font-medium">{meta.label}</span>
      </div>
      <pre className="font-mono text-[10px] text-slate-400 bg-[#0f1117]/60 rounded px-2 py-1.5 mb-3 whitespace-pre-wrap break-all">{wa.preview}</pre>
      {wa.approvalStatus === 'pending' && (
        <div className="flex gap-2">
          <button onClick={onConfirm} className="px-3 py-1 bg-amber-600 hover:bg-amber-500 rounded text-xs text-white font-medium transition-colors">确认执行</button>
          <button onClick={onReject} className="px-3 py-1 bg-slate-700 hover:bg-slate-600 rounded text-xs text-slate-300 transition-colors">拒绝</button>
        </div>
      )}
      {wa.approvalStatus === 'confirmed' && wa.confirmedBy && (
        <p className="text-[10px] text-emerald-400/70">由 {wa.confirmedBy} 确认于 {wa.confirmedAt ? new Date(wa.confirmedAt).toLocaleString('zh-CN') : '—'}</p>
      )}
    </div>
  );
}

function ClaimCard({ claim, index, toolCallLog, onCitationClick, phase2Enabled }: {
  claim: Claim;
  index: number;
  toolCallLog: ToolCall[];
  onCitationClick: (tc: ToolCall, cit: Citation) => void;
  phase2Enabled: boolean;
}) {
  return (
    <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg p-4">
      <div className="flex items-start gap-2 mb-3">
        <span className="font-mono text-xs text-slate-600 flex-shrink-0 mt-0.5">{index}.</span>
        <p className="text-sm text-slate-200 leading-relaxed">{claim.text}</p>
      </div>
      <div className="flex flex-wrap gap-2 pl-4">
        {claim.citations.map(cit => {
          const tc = toolCallLog.find(t => t.id === cit.toolCallId);
          if (!tc) return null;
          return (
            <button
              key={cit.id}
              onClick={() => onCitationClick(tc, cit)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] hover:opacity-80 transition-colors font-mono border ${
                tc.isLoki
                  ? 'bg-purple-900/20 border-purple-800/30 text-purple-400'
                  : 'bg-emerald-900/20 border-emerald-800/30 text-emerald-400'
              }`}
            >
              <span>{tc.isLoki ? '⊕' : '⊛'}</span>
              <span>{tc.tool}</span>
              {phase2Enabled && tc.isLoki && <span className="text-[9px] opacity-60">Loki</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function GateCounter({ label, used, limit, unit = '' }: { label: string; used: number; limit: number; unit?: string }) {
  const pct = Math.min((used / limit) * 100, 100);
  const over = used >= limit;
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-slate-500">{label}</span>
        <span className={`font-mono text-xs ${over ? 'text-red-400' : 'text-slate-400'}`}>{used}{unit}/{limit}{unit}</span>
      </div>
      <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${over ? 'bg-red-500' : pct > 75 ? 'bg-amber-500' : 'bg-blue-500'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function Spinner() {
  return (
    <svg className="animate-spin h-3 w-3" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  );
}
