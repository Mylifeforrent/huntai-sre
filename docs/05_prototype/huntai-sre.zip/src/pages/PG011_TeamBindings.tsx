import { useState } from 'react';
import { MOCK_TEAM_BINDINGS } from '../mock/clusters';
import ConfirmModal from '../components/ConfirmModal';

interface Binding {
  id: string;
  idpGroup: string;
  labelType: 'team' | 'owner' | 'namespace';
  labelValue: string;
}

export default function PG011_TeamBindings() {
  const [bindings, setBindings] = useState<Binding[]>([...MOCK_TEAM_BINDINGS]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ idpGroup: '', labelType: 'team' as Binding['labelType'], labelValue: '' });
  const [formError, setFormError] = useState<Record<string, string>>({});
  const [confirmPending, setConfirmPending] = useState<Binding | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);

  const validate = () => {
    const errors: Record<string, string> = {};
    if (!form.idpGroup) errors.idpGroup = 'IdP 组名必填';
    if (!form.labelValue) errors.labelValue = '标签值必填';
    return errors;
  };

  const handleSubmit = () => {
    const errors = validate();
    if (Object.keys(errors).length) { setFormError(errors); return; }
    setConfirmPending({ id: `tb-${Date.now()}`, ...form });
  };

  const handleConfirm = () => {
    if (!confirmPending) return;
    setSaving(true);
    setConfirmPending(null);
    setTimeout(() => {
      setBindings(prev => [...prev, confirmPending]);
      (MOCK_TEAM_BINDINGS as Binding[]).push(confirmPending);
      setSavedId(confirmPending.id);
      setSaving(false);
      setShowForm(false);
      setForm({ idpGroup: '', labelType: 'team', labelValue: '' });
      setTimeout(() => setSavedId(null), 2000);
    }, 600);
  };

  const LABEL_TYPE_LABELS = { team: 'team', owner: 'owner', namespace: 'namespace' };

  return (
    <div className="h-full flex flex-col">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-slate-100">团队绑定</h1>
          <p className="text-xs text-slate-500 mt-0.5">IdP 组 → 告警标签值映射</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          disabled={showForm || saving}
          className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-sm font-medium transition-colors"
        >
          添加绑定
        </button>
      </div>

      <div className="flex-1 overflow-auto px-6 py-6">
        {/* Namespace note */}
        <div className="mb-5 px-3 py-2 bg-slate-800/40 border border-slate-700/40 rounded text-xs text-slate-400 flex items-start gap-2">
          <span className="text-slate-600">ℹ</span>
          <span>无 team 标签时，以 namespace 为缺省匹配键（BR-013）。禁止用户自助勾选团队。所有变更均写入审计日志。</span>
        </div>

        {/* Add form */}
        {showForm && (
          <div className="mb-5 bg-[#1a1d27] border border-blue-600/30 rounded-lg p-5 max-w-lg">
            <div className="text-sm font-medium text-slate-200 mb-4">添加团队绑定</div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">IdP 组名 *</label>
                <input
                  value={form.idpGroup}
                  onChange={e => setForm(f => ({ ...f, idpGroup: e.target.value }))}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                  placeholder="eng-payments"
                />
                {formError.idpGroup && <p className="mt-1 text-xs text-red-400">{formError.idpGroup}</p>}
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">标签类型 *</label>
                <div className="flex gap-2">
                  {(['team', 'owner', 'namespace'] as const).map(t => (
                    <button
                      key={t}
                      onClick={() => setForm(f => ({ ...f, labelType: t }))}
                      className={`px-3 py-1 rounded text-xs transition-colors border ${
                        form.labelType === t ? 'border-blue-500/50 bg-blue-600/20 text-blue-400' : 'border-slate-700 text-slate-400 hover:border-slate-600'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">标签值 *</label>
                <input
                  value={form.labelValue}
                  onChange={e => setForm(f => ({ ...f, labelValue: e.target.value }))}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                  placeholder={form.labelType === 'team' ? 'payments' : form.labelType === 'namespace' ? 'payments-prod' : 'owner-name'}
                />
                {formError.labelValue && <p className="mt-1 text-xs text-red-400">{formError.labelValue}</p>}
              </div>
              <div className="flex gap-2">
                <button
                  disabled={saving}
                  onClick={handleSubmit}
                  className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm transition-colors"
                >
                  {saving ? '保存中…' : '保存'}
                </button>
                <button
                  onClick={() => { setShowForm(false); setFormError({}); }}
                  className="px-4 py-2 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm transition-colors"
                >
                  取消
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Bindings table */}
        <div className="bg-[#1a1d27] border border-slate-700/60 rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700/40 text-[11px] text-slate-500 uppercase tracking-wide">
                <th className="px-4 py-3 text-left font-medium">IdP 组</th>
                <th className="px-4 py-3 text-left font-medium">标签类型</th>
                <th className="px-4 py-3 text-left font-medium">标签值</th>
              </tr>
            </thead>
            <tbody>
              {bindings.map(b => (
                <tr key={b.id} className={`border-b border-slate-700/20 transition-colors ${savedId === b.id ? 'bg-emerald-900/10' : ''}`}>
                  <td className="px-4 py-3">
                    <span className="font-mono text-xs text-slate-300">{b.idpGroup}</span>
                    {savedId === b.id && <span className="ml-2 text-xs text-emerald-400">已保存</span>}
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-mono">{LABEL_TYPE_LABELS[b.labelType]}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-mono text-xs text-slate-400">{b.labelValue}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <p className="mt-3 text-xs text-slate-600">撤销绑定 = 再次提交新绑定变更（仍写审计日志），不提供「撤销上一次」快捷操作。</p>
      </div>

      {confirmPending && (
        <ConfirmModal
          title="确认修改团队绑定"
          description={
            <div className="space-y-2">
              <p>将添加以下绑定（变更将写入审计日志）：</p>
              <div className="bg-[#0f1117] rounded px-3 py-2 font-mono text-xs text-slate-300 space-y-1">
                <div>IdP 组: {confirmPending.idpGroup}</div>
                <div>标签类型: {confirmPending.labelType}</div>
                <div>标签值: {confirmPending.labelValue}</div>
              </div>
            </div>
          }
          confirmLabel="确认添加"
          onConfirm={handleConfirm}
          onCancel={() => setConfirmPending(null)}
        />
      )}
    </div>
  );
}
