import { useState, type ReactNode } from 'react';
import { useApp } from '../App';
import { MOCK_CLUSTERS } from '../mock/clusters';
import { ClusterSource, ClusterEnv } from '../mock/types';

function Phase2Badge() {
  return (
    <span className="px-1.5 py-0.5 bg-violet-900/40 border border-violet-700/40 text-violet-400 text-[9px] rounded font-mono">〔二期〕</span>
  );
}

export default function PG009_DataSources() {
  const { navigate, phase2Enabled } = useApp();
  const [clusters, setClusters] = useState<ClusterSource[]>([...MOCK_CLUSTERS]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    cluster_id: '',
    amWebhook: '',
    promUrl: '',
    env: '' as ClusterEnv | '',
    writeRemediationEnabled: false,
    scaleMax: '',
    lokiConfigured: false,
    writeIdentityConfigured: false,
  });
  const [formError, setFormError] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);

  const atLimit = clusters.length >= 5;

  const validate = () => {
    const errors: Record<string, string> = {};
    if (!form.cluster_id) errors.cluster_id = 'cluster_id 必填';
    else if (clusters.find(c => c.cluster_id === form.cluster_id)) errors.cluster_id = 'cluster_id 已存在';
    if (!form.amWebhook) errors.amWebhook = 'AM Webhook URL 必填';
    if (!form.promUrl) errors.promUrl = 'Prometheus 只读 URL 必填';
    if (!form.env) errors.env = '环境分类必填，不可从 cluster_id 推断';
    if (form.writeRemediationEnabled && form.scaleMax && (!/^\d+$/.test(form.scaleMax) || parseInt(form.scaleMax) <= 0)) {
      errors.scaleMax = '请输入正整数';
    }
    return errors;
  };

  const handleSave = () => {
    const errors = validate();
    if (Object.keys(errors).length) { setFormError(errors); return; }
    setSaving(true);
    setTimeout(() => {
      const newCluster: ClusterSource = {
        id: `cs-new-${Date.now()}`,
        cluster_id: form.cluster_id,
        env: form.env as ClusterEnv,
        amWebhookConfigured: true,
        promConfigured: true,
        analyzerEnabled: false,
        writeRemediationEnabled: form.writeRemediationEnabled,
        scaleMax: form.scaleMax ? parseInt(form.scaleMax) : undefined,
        lokiConfigured: form.lokiConfigured,
        writeIdentityConfigured: form.writeIdentityConfigured,
      };
      setClusters(prev => [...prev, newCluster]);
      MOCK_CLUSTERS.push(newCluster);
      setSaving(false);
      setShowForm(false);
      setForm({ cluster_id: '', amWebhook: '', promUrl: '', env: '', writeRemediationEnabled: false, scaleMax: '', lokiConfigured: false, writeIdentityConfigured: false });
      setSavedId(newCluster.id);
      setTimeout(() => setSavedId(null), 2000);
    }, 800);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-slate-100">数据源</h1>
          <p className="text-xs text-slate-500 mt-0.5">{clusters.length}/5 个集群已注册</p>
        </div>
        <button
          disabled={atLimit || showForm}
          onClick={() => setShowForm(true)}
          className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors"
          title={atLimit ? '已达一期集群上限（5 个）' : ''}
        >
          注册集群
        </button>
      </div>

      <div className="flex-1 overflow-auto px-6 py-6">
        {/* Credential note */}
        <div className="mb-5 px-3 py-2 bg-slate-800/40 border border-slate-700/40 rounded text-xs text-slate-400 flex items-start gap-2">
          <span className="text-slate-600 mt-0.5">ℹ</span>
          <span>接入凭证（IngestCredential）与账号 OIDC 身份分离（BR-016）。密钥仅展示已配置状态，不回显明文。禁止上传 kubeconfig。</span>
        </div>

        {/* Add form */}
        {showForm && (
          <div className="mb-6 bg-[#1a1d27] border border-blue-600/30 rounded-lg p-5 max-w-xl">
            <div className="text-sm font-medium text-slate-200 mb-4">注册新集群</div>
            <div className="space-y-4">
              <FormField label="cluster_id *" error={formError.cluster_id}>
                <input
                  type="text"
                  value={form.cluster_id}
                  onChange={e => setForm(f => ({ ...f, cluster_id: e.target.value }))}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                  placeholder="prod-us-east-1"
                />
              </FormField>

              <FormField label="环境分类 *" error={formError.env}>
                <div className="text-[10px] text-slate-600 mb-1.5">必填，不可从 cluster_id 推断</div>
                <div className="flex gap-3">
                  {(['production', 'non_production'] as ClusterEnv[]).map(env => (
                    <label key={env} className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="env" value={env} checked={form.env === env}
                        onChange={() => setForm(f => ({ ...f, env }))}
                        className="accent-blue-500" />
                      <span className="text-xs text-slate-300 font-mono">{env}</span>
                    </label>
                  ))}
                </div>
              </FormField>

              <FormField label="Alertmanager Webhook URL *" error={formError.amWebhook}>
                <input
                  type="url"
                  value={form.amWebhook}
                  onChange={e => setForm(f => ({ ...f, amWebhook: e.target.value }))}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                  placeholder="https://huntai.internal/webhook/..."
                />
              </FormField>

              <FormField label="Prometheus 只读 URL *" error={formError.promUrl}>
                <input
                  type="url"
                  value={form.promUrl}
                  onChange={e => setForm(f => ({ ...f, promUrl: e.target.value }))}
                  className="w-full bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                  placeholder="https://prom.internal"
                />
              </FormField>

              {/* Phase 2 section */}
              <div className="border-t border-slate-700/40 pt-4 space-y-4">
                <div className="text-xs text-slate-500 flex items-center gap-2">
                  <span className="text-purple-400 font-medium">〔二期〕</span>写操作与 Loki 配置（可选）
                </div>

                <FormField label="〔二期〕写操作修复（Write Remediation）" error={undefined}>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={form.writeRemediationEnabled}
                      onChange={e => setForm(f => ({ ...f, writeRemediationEnabled: e.target.checked }))}
                      className="accent-blue-500 w-3.5 h-3.5" />
                    <span className="text-xs text-slate-300">启用写操作修复</span>
                  </label>
                </FormField>

                {form.writeRemediationEnabled && (
                  <FormField label="〔二期〕Scale 最大副本数（scale_max）" error={formError.scaleMax}>
                    <input
                      type="text"
                      value={form.scaleMax}
                      onChange={e => setForm(f => ({ ...f, scaleMax: e.target.value }))}
                      className="w-32 bg-[#0f1117] border border-slate-700 rounded px-3 py-2 text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
                      placeholder="如 10"
                    />
                  </FormField>
                )}

                <FormField label="〔二期〕WriteIdentity 凭证" error={undefined}>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={form.writeIdentityConfigured}
                      onChange={e => setForm(f => ({ ...f, writeIdentityConfigured: e.target.checked }))}
                      className="accent-blue-500 w-3.5 h-3.5" />
                    <span className="text-xs text-slate-300">已配置 WriteIdentity 凭证</span>
                  </label>
                </FormField>

                <FormField label="〔二期〕Loki LogQL 接入" error={undefined}>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={form.lokiConfigured}
                      onChange={e => setForm(f => ({ ...f, lokiConfigured: e.target.checked }))}
                      className="accent-blue-500 w-3.5 h-3.5" />
                    <span className="text-xs text-slate-300">已接入 Loki（LogQL 查询结果可作 Citation）</span>
                  </label>
                </FormField>
              </div>

              <div className="text-xs text-slate-600">
                已部署实例使用该集群专用只读 ServiceAccount（不支持上传个人 kubeconfig）
              </div>
              <div className="flex gap-2">
                <button
                  disabled={saving}
                  onClick={handleSave}
                  className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm transition-colors"
                >
                  {saving ? '保存中…' : '保存'}
                </button>
                <button onClick={() => { setShowForm(false); setFormError({}); }} className="px-4 py-2 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm transition-colors">取消</button>
              </div>
            </div>
          </div>
        )}

        {/* Cluster list */}
        <div className="space-y-3">
          {clusters.map(cluster => (
            <div
              key={cluster.id}
              className={`bg-[#1a1d27] border rounded-lg p-5 transition-colors ${savedId === cluster.id ? 'border-emerald-600/40' : 'border-slate-700/60'}`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm font-medium text-slate-100">{cluster.cluster_id}</span>
                  {savedId === cluster.id && <span className="text-xs text-emerald-400">已保存</span>}
                  {'env' in cluster && cluster.env && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded border font-mono ${
                      cluster.env === 'production'
                        ? 'text-amber-400 bg-amber-900/15 border-amber-800/20'
                        : 'text-slate-500 bg-slate-800/40 border-slate-700/30'
                    }`}>
                      {cluster.env}
                    </span>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 text-xs mb-3">
                <StatusItem label="AM Webhook" ok={cluster.amWebhookConfigured} />
                <StatusItem label="Prometheus 只读" ok={cluster.promConfigured ?? false} />
                <StatusItem label="规则分析器" ok={cluster.analyzerEnabled ?? false} />
              </div>
              {/* Phase 2 status row */}
              <div className="grid grid-cols-3 gap-4 text-xs mb-3 pt-3 border-t border-slate-700/30">
                <StatusItem label="〔二期〕写操作修复" ok={cluster.writeRemediationEnabled ?? false} />
                <StatusItem label="〔二期〕Loki 接入" ok={cluster.lokiConfigured ?? false} />
                <StatusItem label="〔二期〕WriteIdentity" ok={cluster.writeIdentityConfigured ?? false} />
              </div>
              {cluster.writeRemediationEnabled && cluster.scaleMax && (
                <div className="text-xs text-slate-500 mb-3">scale_max = <span className="font-mono text-slate-400">{cluster.scaleMax}</span></div>
              )}
              <div className="mt-2 pt-3 border-t border-slate-700/40 flex items-center gap-4">
                <div className="text-xs text-slate-500">IngestCredential</div>
                <span className="text-xs text-slate-400 bg-slate-800 px-2 py-0.5 rounded">已配置</span>
                <button className="text-xs text-slate-600 hover:text-slate-400 transition-colors">重新生成</button>

                {/* Phase 2: Loki credential */}
                {phase2Enabled && cluster.lokiConfigured && (
                  <>
                    <div className="text-xs text-slate-500 ml-4">LokiCredential</div>
                    <span className="text-xs text-slate-400 bg-slate-800 px-2 py-0.5 rounded">已配置</span>
                    <Phase2Badge />
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatusItem({ label, ok }: { label: string; ok: boolean }) {
  return (
    <div>
      <div className="text-slate-500 mb-1 text-[11px]">{label}</div>
      <div className={`flex items-center gap-1.5 text-xs ${ok ? 'text-emerald-400' : 'text-slate-600'}`}>
        <span>{ok ? '●' : '○'}</span>
        <span>{ok ? '已配置' : '未配置'}</span>
      </div>
    </div>
  );
}

function FormField({ label, error, children }: { label: string; error?: string; children: ReactNode }) {
  return (
    <div>
      <label className="block text-xs text-slate-400 mb-1.5">{label}</label>
      {children}
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
}
