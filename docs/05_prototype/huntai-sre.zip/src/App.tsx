import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import PG001_Login from './pages/PG001_Login';
import PG002_BreakGlass from './pages/PG002_BreakGlass';
import PG003_AlertList from './pages/PG003_AlertList';
import PG004_DeepLinkMiss from './pages/PG004_DeepLinkMiss';
import PG005_AlertDetail from './pages/PG005_AlertDetail';
import PG006_InvestigationDetail from './pages/PG006_InvestigationDetail';
import PG007_ClusterScan from './pages/PG007_ClusterScan';
import PG008_ScanResult from './pages/PG008_ScanResult';
import PG009_DataSources from './pages/PG009_DataSources';
import PG010_SkillMapping from './pages/PG010_SkillMapping';
import PG011_TeamBindings from './pages/PG011_TeamBindings';
import PG012_QuotaGate from './pages/PG012_QuotaGate';
import AppShell from './components/AppShell';
import DevToolbar from './components/DevToolbar';

export type UserRole = 'sre' | 'dev' | 'breakglass';

export interface AppState {
  role: UserRole;
  loggedIn: boolean;
  llmEnabled: boolean;
  orgGateClosed: boolean;
  userDailyQuota: number; // remaining today
  orgTokenConfigured: boolean;
  orgTokenLimit: string;
  phase2Enabled: boolean; // Phase 2 (二期) feature toggle
  navigate: (path: string) => void;
  goBack: () => void;
  setRole: (r: UserRole) => void;
  setLoggedIn: (v: boolean) => void;
  setLlmEnabled: (v: boolean) => void;
  setOrgGateClosed: (v: boolean) => void;
  setUserDailyQuota: (v: number) => void;
  setOrgTokenConfigured: (v: boolean) => void;
  setOrgTokenLimit: (v: string) => void;
  setPhase2Enabled: (v: boolean) => void;
}

export const AppCtx = createContext<AppState>({} as AppState);
export const useApp = () => useContext(AppCtx);

function parsePath(hash: string): { page: string; params: Record<string, string> } {
  const withoutHash = hash.replace(/^#\/?/, '');
  const [pagePart, queryPart] = withoutHash.split('?');
  const params: Record<string, string> = {};
  if (queryPart) {
    queryPart.split('&').forEach(p => {
      const [k, v] = p.split('=');
      if (k) params[decodeURIComponent(k)] = decodeURIComponent(v || '');
    });
  }
  return { page: pagePart || '', params };
}

const AUTH_PAGES = new Set(['', 'login', 'breakglass']);
const SRE_ONLY_PAGES = new Set(['settings-datasources', 'settings-skills', 'settings-bindings', 'settings-quota']);
const SRE_OR_PHASE2_PAGES = new Set(['scan', 'scan-result']);

export default function App() {
  const [hash, setHash] = useState(window.location.hash);
  const [role, setRole] = useState<UserRole>('sre');
  const [loggedIn, setLoggedIn] = useState(false);
  const [llmEnabled, setLlmEnabled] = useState(true);
  const [orgGateClosed, setOrgGateClosed] = useState(false);
  const [userDailyQuota, setUserDailyQuota] = useState(27);
  const [orgTokenConfigured, setOrgTokenConfigured] = useState(false);
  const [orgTokenLimit, setOrgTokenLimit] = useState('');
  const [phase2Enabled, setPhase2Enabled] = useState(false);

  useEffect(() => {
    const handler = () => setHash(window.location.hash);
    window.addEventListener('hashchange', handler);
    return () => window.removeEventListener('hashchange', handler);
  }, []);

  const navigate = useCallback((path: string) => {
    window.location.hash = path;
  }, []);

  const goBack = useCallback(() => {
    window.history.back();
  }, []);

  const { page, params } = parsePath(hash);

  const isAuthPage = AUTH_PAGES.has(page);
  const isSreOnly = SRE_ONLY_PAGES.has(page) || (SRE_OR_PHASE2_PAGES.has(page) && !phase2Enabled);

  // Redirect logic
  if (!loggedIn && !isAuthPage) {
    return (
      <AppCtx.Provider value={{
        role, loggedIn, llmEnabled, orgGateClosed, userDailyQuota, orgTokenConfigured, orgTokenLimit, phase2Enabled,
        navigate, goBack, setRole, setLoggedIn, setLlmEnabled, setOrgGateClosed,
        setUserDailyQuota, setOrgTokenConfigured, setOrgTokenLimit, setPhase2Enabled,
      }}>
        <PG001_Login redirectTo={hash} />
        <DevToolbar />
      </AppCtx.Provider>
    );
  }

  const ctx: AppState = {
    role, loggedIn, llmEnabled, orgGateClosed, userDailyQuota, orgTokenConfigured, orgTokenLimit, phase2Enabled,
    navigate, goBack, setRole, setLoggedIn, setLlmEnabled, setOrgGateClosed,
    setUserDailyQuota, setOrgTokenConfigured, setOrgTokenLimit, setPhase2Enabled,
  };

  const renderPage = () => {
    if (!loggedIn && (page === '' || page === 'login')) return <PG001_Login />;
    if (page === 'breakglass') return <PG002_BreakGlass />;
    if (isSreOnly && role === 'dev') {
      return (
        <AppShell>
          <NoPermissionPage />
        </AppShell>
      );
    }
    switch (page) {
      case 'alerts':
      case '':
        return <AppShell><PG003_AlertList /></AppShell>;
      case 'deep-link-miss':
        return <AppShell><PG004_DeepLinkMiss params={params} /></AppShell>;
      case 'alert':
        return <AppShell><PG005_AlertDetail alertId={params.id} /></AppShell>;
      case 'investigation':
        return <AppShell><PG006_InvestigationDetail invId={params.id} /></AppShell>;
      case 'scan':
        return <AppShell><PG007_ClusterScan /></AppShell>;
      case 'scan-result':
        return <AppShell><PG008_ScanResult scanId={params.id} /></AppShell>;
      case 'settings-datasources':
        return <AppShell><PG009_DataSources /></AppShell>;
      case 'settings-skills':
        return <AppShell><PG010_SkillMapping /></AppShell>;
      case 'settings-bindings':
        return <AppShell><PG011_TeamBindings /></AppShell>;
      case 'settings-quota':
        return <AppShell><PG012_QuotaGate /></AppShell>;
      default:
        return <AppShell><PG003_AlertList /></AppShell>;
    }
  };

  if (!loggedIn) {
    return (
      <AppCtx.Provider value={ctx}>
        {page === 'breakglass' ? <PG002_BreakGlass /> : <PG001_Login />}
        <DevToolbar />
      </AppCtx.Provider>
    );
  }

  return (
    <AppCtx.Provider value={ctx}>
      {renderPage()}
      <DevToolbar />
    </AppCtx.Provider>
  );
}

function NoPermissionPage() {
  const { navigate } = useApp();
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
      <div className="text-5xl text-slate-600">⊘</div>
      <h2 className="text-xl font-semibold text-slate-300">无访问权限</h2>
      <p className="text-slate-500 text-sm">当前角色（开发 on-call）无法访问此页面。</p>
      <button
        onClick={() => navigate('#alerts')}
        className="mt-2 px-4 py-2 rounded bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm transition-colors"
      >
        返回告警列表
      </button>
    </div>
  );
}
