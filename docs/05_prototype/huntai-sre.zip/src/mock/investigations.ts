import { Investigation, ApprovalRequest } from './types';

export const MOCK_APPROVAL_REQUEST: ApprovalRequest = {
  id: 'apr-001',
  investigationId: 'inv-001',
  status: 'pending',
  action: {
    type: 'restart',
    target: 'payment-processor',
    namespace: 'payments-prod',
    detail: '重启 Deployment payment-processor（当前重启次数 14，建议清理内存峰值状态）',
  },
  requestedAt: '2026-09-13T14:36:50Z',
};

export const MOCK_INVESTIGATIONS: Investigation[] = [
  {
    id: 'inv-001',
    alertId: 'alert-001',
    status: 'completed',
    trigger: 'human',
    startedAt: '2026-09-13T14:35:00Z',
    completedAt: '2026-09-13T14:36:48Z',
    skillLoaded: true,
    llmCalls: 4,
    toolCalls: 7,
    wallClockSeconds: 108,
    userId: 'user-sre-01',
    toolCallLog: [
      {
        id: 'tc-001',
        tool: 'kubectl get pod',
        input: 'kubectl get pod payment-processor-7d9f8b-xk2p4 -n payments-prod -o json',
        output: `{
  "metadata": { "name": "payment-processor-7d9f8b-xk2p4", "namespace": "payments-prod" },
  "status": {
    "phase": "Running",
    "containerStatuses": [{
      "name": "payment-processor",
      "restartCount": 14,
      "lastState": {
        "terminated": { "exitCode": 137, "reason": "OOMKilled", "finishedAt": "2026-09-13T14:31:55Z" }
      }
    }]
  }
}`,
        status: 'success',
      },
      {
        id: 'tc-002',
        tool: 'kubectl describe pod',
        input: 'kubectl describe pod payment-processor-7d9f8b-xk2p4 -n payments-prod',
        output: `Name:         payment-processor-7d9f8b-xk2p4
Namespace:    payments-prod
Events:
  14m   Warning  OOMKilling   node/ip-10-0-1-42  Memory cgroup out of memory: Kill process 8821 (java) score 982 or sacrifice child
  14m   Normal   Pulled       kubelet            Successfully pulled image "payments/processor:v2.4.1"
  13m   Normal   Started      kubelet            Started container payment-processor
Limits:
  memory: 512Mi
Requests:
  memory: 256Mi`,
        status: 'success',
      },
      {
        id: 'tc-003',
        tool: 'prom_query',
        input: 'container_memory_working_set_bytes{pod="payment-processor-7d9f8b-xk2p4",namespace="payments-prod"}',
        output: '[{"metric":{"__name__":"container_memory_working_set_bytes","pod":"payment-processor-7d9f8b-xk2p4"},"value":[1694610000,"536870912"]}]',
        status: 'success',
      },
      {
        id: 'tc-004',
        tool: 'kubectl logs',
        input: 'kubectl logs payment-processor-7d9f8b-xk2p4 -n payments-prod --previous --tail=50',
        output: `2026-09-13T14:31:50Z INFO  Processing batch of 8420 payment records
2026-09-13T14:31:52Z INFO  Allocated result cache: 312MB
2026-09-13T14:31:53Z INFO  Expanding in-memory deduplication index: 178MB
2026-09-13T14:31:54Z WARN  GC overhead limit exceeded, heap at 498MB/512MB
2026-09-13T14:31:55Z ERROR OutOfMemoryError: Java heap space
  at com.payments.BatchProcessor.dedup(BatchProcessor.java:312)
  at com.payments.PaymentJob.run(PaymentJob.java:88)`,
        status: 'success',
      },
      {
        id: 'tc-005',
        tool: 'kubectl get events',
        input: 'kubectl get events -n payments-prod --field-selector involvedObject.name=payment-processor-7d9f8b-xk2p4',
        output: `LAST SEEN   TYPE      REASON      OBJECT                                    MESSAGE
14m         Warning   OOMKilling  pod/payment-processor-7d9f8b-xk2p4       Memory cgroup out of memory: Kill process
13m         Normal    Pulled      pod/payment-processor-7d9f8b-xk2p4       Successfully pulled image
13m         Normal    Started     pod/payment-processor-7d9f8b-xk2p4       Started container`,
        status: 'success',
      },
      {
        id: 'tc-006',
        tool: 'prom_alerts',
        input: 'Get current firing alerts for namespace payments-prod',
        output: '[{"labels":{"alertname":"KubePodCrashLooping","namespace":"payments-prod","severity":"critical"},"annotations":{"description":"payment-processor-7d9f8b-xk2p4 is restarting 14 times / 10 minutes"},"startsAt":"2026-09-13T14:32:11Z"}]',
        status: 'success',
      },
      {
        id: 'tc-007',
        tool: 'kubectl describe node',
        input: 'kubectl describe node ip-10-0-1-42',
        output: 'Failed to get node details: connection timeout after 30s',
        status: 'failed',
      },
      // Phase 2: Loki tool call
      {
        id: 'tc-008',
        tool: 'loki_query',
        input: '{namespace="payments-prod", pod=~"payment-processor.*"} |= "OOM" | json | line_format "{{.time}} {{.level}} {{.msg}}"',
        output: `2026-09-13T14:31:54Z WARN  GC overhead limit exceeded, heap at 498MB/512MB
2026-09-13T14:31:55Z ERROR OutOfMemoryError: Java heap space at com.payments.BatchProcessor.dedup`,
        status: 'success',
        isLoki: true,
      },
    ],
    claims: [
      {
        id: 'claim-001',
        text: 'Pod payment-processor-7d9f8b-xk2p4 被 OOMKilled，累计重启 14 次。容器内存限制为 512Mi，崩溃前堆内存已达 498MB/512MB。',
        citations: [
          { id: 'cit-001', toolCallId: 'tc-001', excerpt: '"restartCount": 14, "reason": "OOMKilled"' },
          { id: 'cit-002', toolCallId: 'tc-002', excerpt: 'Memory cgroup out of memory: Kill process 8821 (java)' },
        ],
      },
      {
        id: 'claim-002',
        text: '根本原因：批处理任务在处理 8420 条支付记录时，同时分配了 312MB 结果缓存与 178MB 去重索引，共 490MB，超出 512Mi 内存限制。',
        citations: [
          { id: 'cit-003', toolCallId: 'tc-004', excerpt: 'Allocated result cache: 312MB\n  Expanding in-memory deduplication index: 178MB\n  OutOfMemoryError: Java heap space' },
        ],
      },
      {
        id: 'claim-003',
        text: '即时 PromQL 确认崩溃前工作集达 512MB（536870912 bytes），与 OOMKill 时间点吻合。',
        citations: [
          { id: 'cit-004', toolCallId: 'tc-003', excerpt: '"value":[1694610000,"536870912"]' },
        ],
      },
    ],
    writeActions: [
      {
        id: 'wa-001',
        verb: 'restart',
        target: 'deployment/payment-processor',
        namespace: 'payments-prod',
        preview: 'kubectl rollout restart deployment/payment-processor -n payments-prod',
        approvalStatus: 'pending',
      },
    ],
  },
  {
    id: 'inv-auto-001',
    alertId: 'alert-001',
    status: 'completed',
    trigger: 'auto',
    startedAt: '2026-09-13T14:32:30Z',
    completedAt: '2026-09-13T14:34:10Z',
    skillLoaded: true,
    llmCalls: 3,
    toolCalls: 5,
    wallClockSeconds: 100,
    userId: 'auto-investigator',
    toolCallLog: [
      {
        id: 'atc-001',
        tool: 'kubectl get pod',
        input: 'kubectl get pod -n payments-prod -l alertname=KubePodCrashLooping',
        output: 'NAME  READY  STATUS  RESTARTS\npayment-processor-7d9f8b-xk2p4  0/1  CrashLoopBackOff  12',
        status: 'success',
      },
      {
        id: 'atc-002',
        tool: 'loki_logql',
        input: '{namespace="payments-prod", pod="payment-processor-7d9f8b-xk2p4"} |= "OOM" | last 5m',
        output: `2026-09-13T14:31:55Z  payment-processor-7d9f8b-xk2p4  ERROR OutOfMemoryError: Java heap space
2026-09-13T14:31:54Z  payment-processor-7d9f8b-xk2p4  WARN  GC overhead limit exceeded, heap at 498MB/512MB`,
        status: 'success',
        isLoki: true,
      },
      {
        id: 'atc-003',
        tool: 'prom_query',
        input: 'container_memory_working_set_bytes{namespace="payments-prod"}',
        output: '"value": "536870912"',
        status: 'success',
      },
    ],
    claims: [
      {
        id: 'auto-claim-001',
        text: '自动调查确认：Pod 因 OOMKilled 崩溃，Loki 日志显示 GC overhead 超限后 Java heap space 耗尽。',
        citations: [
          { id: 'auto-cit-001', toolCallId: 'atc-002', excerpt: 'OutOfMemoryError: Java heap space\nGC overhead limit exceeded, heap at 498MB/512MB' },
          { id: 'auto-cit-002', toolCallId: 'atc-003', excerpt: '"value": "536870912"' },
        ],
      },
    ],
  },
  {
    id: 'inv-002',
    alertId: 'alert-001',
    status: 'inconclusive',
    trigger: 'human',
    startedAt: '2026-09-13T10:12:00Z',
    completedAt: '2026-09-13T10:14:30Z',
    skillLoaded: false,
    llmCalls: 8,
    toolCalls: 12,
    wallClockSeconds: 150,
    inconclusiveReason: 'cost_gate_time',
    userId: 'user-dev-02',
    toolCallLog: [
      {
        id: 'tc-101',
        tool: 'kubectl get pod',
        input: 'kubectl get pod payment-processor-7d9f8b-xk2p4 -n payments-prod',
        output: 'NAME                                   READY   STATUS             RESTARTS   AGE\npayment-processor-7d9f8b-xk2p4        0/1     CrashLoopBackOff   9          42m',
        status: 'success',
      },
      {
        id: 'tc-102',
        tool: 'kubectl logs',
        input: 'kubectl logs payment-processor-7d9f8b-xk2p4 -n payments-prod --previous',
        output: '[output truncated at 32KB]',
        status: 'success',
        truncated: true,
      },
    ],
    claims: [],
  },
  {
    id: 'inv-003',
    alertId: 'alert-003',
    status: 'inconclusive',
    trigger: 'human',
    startedAt: '2026-09-13T12:20:00Z',
    completedAt: '2026-09-13T12:20:45Z',
    skillLoaded: true,
    llmCalls: 2,
    toolCalls: 3,
    wallClockSeconds: 45,
    inconclusiveReason: 'no_citation',
    userId: 'user-sre-01',
    toolCallLog: [
      {
        id: 'tc-201',
        tool: 'kubectl get deployment',
        input: 'kubectl get deployment order-api -n orders-prod',
        output: 'NAME        READY   UP-TO-DATE   AVAILABLE   AGE\norder-api   2/5     3            2           8d',
        status: 'success',
      },
      {
        id: 'tc-202',
        tool: 'kubectl get events',
        input: 'kubectl get events -n orders-prod --sort-by=.lastTimestamp',
        output: 'Error from server: failed to list events: etcdserver: request timed out',
        status: 'failed',
      },
      {
        id: 'tc-203',
        tool: 'prom_query',
        input: 'kube_deployment_status_replicas_available{deployment="order-api",namespace="orders-prod"}',
        output: 'Error: context deadline exceeded',
        status: 'failed',
      },
    ],
    claims: [],
  },
  // Phase 2: Auto-triggered investigation for alert-001 (severity=critical)
  {
    id: 'inv-004',
    alertId: 'alert-001',
    status: 'completed',
    trigger: 'auto',
    startedAt: '2026-09-13T14:32:15Z',
    completedAt: '2026-09-13T14:33:50Z',
    skillLoaded: true,
    llmCalls: 3,
    toolCalls: 5,
    wallClockSeconds: 95,
    userId: 'system',
    toolCallLog: [
      {
        id: 'tc-401',
        tool: 'kubectl get pod',
        input: 'kubectl get pod payment-processor-7d9f8b-xk2p4 -n payments-prod -o json',
        output: '{"status":{"containerStatuses":[{"restartCount":11,"lastState":{"terminated":{"exitCode":137,"reason":"OOMKilled"}}}]}}',
        status: 'success',
      },
      {
        id: 'tc-402',
        tool: 'kubectl logs',
        input: 'kubectl logs payment-processor-7d9f8b-xk2p4 -n payments-prod --previous --tail=30',
        output: '2026-09-13T14:31:55Z ERROR OutOfMemoryError: Java heap space',
        status: 'success',
      },
      {
        id: 'tc-403',
        tool: 'loki_query',
        input: '{namespace="payments-prod"} |= "OOMKilled" | json',
        output: '2026-09-13T14:31:55Z level=error msg="OOMKilled" pod="payment-processor-7d9f8b-xk2p4" exitCode=137',
        status: 'success',
        isLoki: true,
      },
    ],
    claims: [
      {
        id: 'claim-401',
        text: '自动调查确认 Pod 多次 OOMKilled，Loki 日志与 Kubernetes 事件一致，根因为内存超限。',
        citations: [
          { id: 'cit-401', toolCallId: 'tc-401', excerpt: '"exitCode": 137, "reason": "OOMKilled"' },
          { id: 'cit-402', toolCallId: 'tc-403', excerpt: 'OOMKilled pod="payment-processor" exitCode=137' },
        ],
      },
    ],
  },
];

export function getInvestigationsByAlertId(alertId: string): Investigation[] {
  return MOCK_INVESTIGATIONS.filter(i => i.alertId === alertId);
}

export function getInvestigationById(id: string): Investigation | undefined {
  return MOCK_INVESTIGATIONS.find(i => i.id === id);
}
