import { ScanRun } from './types';

export const MOCK_SCAN_RUNS: ScanRun[] = [
  {
    id: 'scan-001',
    cluster_id: 'prod-us-east-1',
    status: 'completed',
    trigger: 'manual',
    startedAt: '2026-09-13T14:00:00Z',
    completedAt: '2026-09-13T14:00:47Z',
    findings: [
      {
        id: 'find-001',
        rule: 'CrashLoopBackOff',
        resource: 'pod/payment-processor-7d9f8b-xk2p4',
        namespace: 'payments-prod',
        severity: 'critical',
        detail: 'Pod 连续崩溃 14 次，exitCode=137（OOMKilled）。',
      },
      {
        id: 'find-002',
        rule: 'ImagePullBackOff',
        resource: 'pod/payment-worker-5b6c7d-abc12',
        namespace: 'payments-prod',
        severity: 'critical',
        detail: '镜像 payments/worker:v2.5.0-rc1 拉取失败，镜像仓库返回 401。',
      },
      {
        id: 'find-003',
        rule: 'PodPendingScheduling',
        resource: 'pod/analytics-job-8xk2p',
        namespace: 'analytics',
        severity: 'warning',
        detail: 'Pod 已 Pending 23 分钟，原因：Insufficient memory（所需 8Gi，集群可调度 3.2Gi）。',
      },
    ],
  },
  {
    id: 'scan-002',
    cluster_id: 'prod-ap-southeast-1',
    status: 'completed',
    trigger: 'scheduled',
    startedAt: '2026-09-13T13:00:00Z',
    completedAt: '2026-09-13T13:00:52Z',
    findings: [
      {
        id: 'find-004',
        rule: 'DeploymentReplicasMismatch',
        resource: 'deployment/order-api',
        namespace: 'orders-prod',
        severity: 'critical',
        detail: '期望副本数 5，就绪副本数 2，持续时间超过 30 分钟。',
      },
    ],
  },
  {
    id: 'scan-003',
    cluster_id: 'staging-us-east-1',
    status: 'scan_failed',
    trigger: 'scheduled',
    startedAt: '2026-09-13T12:00:00Z',
    completedAt: '2026-09-13T12:00:12Z',
    findings: [],
  },
  {
    id: 'scan-004',
    cluster_id: 'prod-us-east-1',
    status: 'completed',
    trigger: 'scheduled',
    startedAt: '2026-09-12T08:00:00Z',
    completedAt: '2026-09-12T08:00:41Z',
    findings: [],
  },
  {
    id: 'scan-005',
    cluster_id: 'prod-us-east-1',
    status: 'completed',
    trigger: 'scheduled',
    startedAt: '2026-09-13T13:00:00Z',
    completedAt: '2026-09-13T13:00:39Z',
    findings: [
      {
        id: 'find-005',
        rule: 'CrashLoopBackOff',
        resource: 'pod/payment-processor-7d9f8b-xk2p4',
        namespace: 'payments-prod',
        severity: 'critical',
        detail: 'Pod 已连续崩溃（定时扫描发现）。',
      },
    ],
  },
];

export function getScanRunById(id: string): ScanRun | undefined {
  return MOCK_SCAN_RUNS.find(s => s.id === id);
}

export function getScanRunsByCluster(cluster_id: string): ScanRun[] {
  return MOCK_SCAN_RUNS.filter(s => s.cluster_id === cluster_id);
}
