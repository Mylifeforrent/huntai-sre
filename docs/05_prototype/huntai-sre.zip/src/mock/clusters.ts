import { ClusterSource } from './types';

export const MOCK_CLUSTERS: ClusterSource[] = [
  {
    id: 'cs-001',
    cluster_id: 'prod-us-east-1',
    env: 'production',
    amWebhookConfigured: true,
    promConfigured: true,
    analyzerEnabled: true,
    writeRemediationEnabled: true,
    scaleMax: 10,
    lokiConfigured: true,
    writeIdentityConfigured: true,
  },
  {
    id: 'cs-002',
    cluster_id: 'prod-ap-southeast-1',
    env: 'production',
    amWebhookConfigured: true,
    promConfigured: true,
    analyzerEnabled: true,
    writeRemediationEnabled: false,
    lokiConfigured: false,
    writeIdentityConfigured: false,
  },
  {
    id: 'cs-003',
    cluster_id: 'staging-us-east-1',
    env: 'non_production',
    amWebhookConfigured: true,
    promConfigured: false,
    analyzerEnabled: false,
    writeRemediationEnabled: false,
    lokiConfigured: false,
    writeIdentityConfigured: false,
  },
];

export const MOCK_TEAM_BINDINGS = [
  { id: 'tb-001', idpGroup: 'eng-payments', labelType: 'team' as const, labelValue: 'payments' },
  { id: 'tb-002', idpGroup: 'eng-platform', labelType: 'team' as const, labelValue: 'platform' },
  { id: 'tb-003', idpGroup: 'eng-orders', labelType: 'team' as const, labelValue: 'order-service' },
  { id: 'tb-004', idpGroup: 'eng-frontend', labelType: 'team' as const, labelValue: 'frontend' },
  { id: 'tb-005', idpGroup: 'eng-orders', labelType: 'namespace' as const, labelValue: 'orders-prod' },
  { id: 'tb-006', idpGroup: 'eng-payments', labelType: 'namespace' as const, labelValue: 'payments-prod' },
];

export const MOCK_SKILL_MAPPINGS = [
  { id: 'sm-001', scope: '全局', scopeValue: '', gitRepo: 'https://git.internal/huntai/skills.git', branch: 'main' },
  { id: 'sm-002', scope: '集群', scopeValue: 'prod-us-east-1', gitRepo: 'https://git.internal/huntai/skills-prod-east.git', branch: 'main' },
];

export const MOCK_USERS = [
  { id: 'user-sre-01', name: 'Li Wei', role: 'sre', email: 'liwei@corp.internal', dailyUsed: 3 },
  { id: 'user-dev-02', name: 'Chen Jing', role: 'dev', email: 'chenjing@corp.internal', dailyUsed: 30 },
  { id: 'user-dev-03', name: 'Wang Fang', role: 'dev', email: 'wangfang@corp.internal', dailyUsed: 12 },
  { id: 'user-sre-04', name: 'Zhang Lei', role: 'sre', email: 'zhanglei@corp.internal', dailyUsed: 0 },
];
