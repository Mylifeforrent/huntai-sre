export type AlertStatus = 'firing' | 'resolved';
export type InvestigationStatus = 'running' | 'completed' | 'inconclusive';
export type InvestigationTrigger = 'human' | 'auto';
export type ScanRunStatus = 'running' | 'completed' | 'scan_failed';
export type ScanRunTrigger = 'manual' | 'scheduled';
export type ApprovalStatus = 'pending' | 'confirmed' | 'rejected' | 'void';
export type WriteVerb = 'restart' | 'scale';
export type ClusterEnv = 'production' | 'non_production';

export interface Alert {
  id: string;
  fingerprint: string;
  cluster_id: string;
  alertname: string;
  status: AlertStatus;
  severity?: string;
  team?: string;
  owner?: string;
  namespace?: string;
  unscoped: boolean;
  receivedAt: string;
  labels: Record<string, string>;
  relatedLinks: RelatedLink[];
}

export interface RelatedLink {
  id: string;
  url: string;
  label: string;
}

export interface ToolCall {
  id: string;
  tool: string;
  input: string;
  output: string;
  status: 'success' | 'failed';
  truncated?: boolean;
  isLoki?: boolean;
}

export interface Citation {
  id: string;
  toolCallId: string;
  excerpt: string;
}

export interface Claim {
  id: string;
  text: string;
  citations: Citation[];
}

export interface WriteAction {
  id: string;
  verb: WriteVerb;
  target: string;
  namespace: string;
  preview: string;
  scaleTarget?: number;
  approvalStatus: ApprovalStatus;
  confirmedBy?: string;
  confirmedAt?: string;
}

export interface Investigation {
  id: string;
  alertId: string;
  status: InvestigationStatus;
  trigger: InvestigationTrigger;
  startedAt: string;
  completedAt?: string;
  skillLoaded: boolean;
  llmCalls: number;
  toolCalls: number;
  wallClockSeconds: number;
  inconclusiveReason?: 'no_citation' | 'cost_gate_llm' | 'cost_gate_tool' | 'cost_gate_time';
  claims: Claim[];
  toolCallLog: ToolCall[];
  userId: string;
  writeActions?: WriteAction[];
}

export interface Finding {
  id: string;
  rule: string;
  resource: string;
  namespace: string;
  severity: 'critical' | 'warning' | 'info';
  detail: string;
}

export interface ScanRun {
  id: string;
  cluster_id: string;
  status: ScanRunStatus;
  trigger: ScanRunTrigger;
  startedAt: string;
  completedAt?: string;
  findings: Finding[];
}

export interface ClusterSource {
  id: string;
  cluster_id: string;
  env: ClusterEnv;
  amWebhookConfigured: boolean;
  promConfigured: boolean;
  analyzerEnabled: boolean;
  writeRemediationEnabled: boolean;
  scaleMax?: number;
  lokiConfigured: boolean;
  writeIdentityConfigured: boolean;
}
