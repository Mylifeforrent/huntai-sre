# HuntAI SRE Prototype Plan

## Context

Convert the HuntAI SRE business model (business_model.md) and interaction design (interaction_design_summary.md) into a clickable prototype covering all 12 pages and core user flows. The prototype must faithfully map business rules to UI without inventing new capabilities. No production data, no real APIs — mock state and simulated async behavior only.

---

## Aesthetic Stance

**Internal SRE ops tool** — functional density over brand flair. No editorial warmth, no gradient heroes. Commit to: neutral dark-slate ground (`#0f1117` bg, `#1a1d27` cards), structured monospace data labels, clean sans body text. Status colors are semantic, not decorative.

- **Body**: Inter (Google Fonts)
- **Mono**: JetBrains Mono — fingerprints, cluster_id, tool call outputs, code blocks
- **Ground**: Dark slate. Alert status: `firing` = amber, `resolved` = emerald. Investigation: `running` = sky blue, `completed` = emerald, `inconclusive` = amber-orange
- **Primary action**: `#3b82f6` (blue-500)
- No rounded-card-on-gray SaaS defaults

---

## Architecture

### Router & State
- Install `react-router-dom` v6 for client-side routing
- Global `AppContext` (React context) carries: `currentRole` (`sre` | `dev` | `breakglass`), `llmEnabled` (bool), `orgGateOpen` (bool), `userDailyQuota` (number remaining)
- A **DevToolbar** (fixed bottom-right, prototype-only) lets reviewers switch role and toggle LLM/gate — makes all role-gated states demoable without re-login

### Mock Data Module (`src/mock/`)
- `alerts.ts` — 8–10 Alert objects with varied `cluster_id`, `team`/`namespace`/`unscoped`, `firing`/`resolved` states
- `investigations.ts` — investigations in `running`, `completed`, `inconclusive` states with Claims + Citations + ToolCalls
- `scanRuns.ts` — ScanRuns with Findings
- `clusters.ts` — 3 ClusterSources

### File Structure
```
src/
  App.tsx              # Router setup + AppContext
  index.css            # Google Fonts @import + Tailwind + theme tokens
  mock/
    alerts.ts
    investigations.ts
    scanRuns.ts
    clusters.ts
  components/
    AppShell.tsx        # NAV-000: left nav (role-aware) + top bar + DevToolbar
    ConfirmModal.tsx    # IX-CNF reusable confirm dialog
    StatusBadge.tsx     # firing/resolved/running/completed/inconclusive
    LLMBanner.tsx       # BR-026/BR-050 global banner when llmEnabled=false
    BreakGlassBanner.tsx # BR-011 persistent banner
  pages/
    PG001_Login.tsx
    PG002_BreakGlass.tsx
    PG003_AlertList.tsx
    PG004_DeepLinkMiss.tsx
    PG005_AlertDetail.tsx
    PG006_InvestigationDetail.tsx
    PG007_ClusterScan.tsx
    PG008_ScanResult.tsx
    PG009_DataSources.tsx
    PG010_SkillMapping.tsx
    PG011_TeamBindings.tsx
    PG012_QuotaGate.tsx
```

---

## Page-by-Page Implementation Plan

### PG-001 Login
- Centered card, product name "HuntAI SRE", primary CTA "使用公司账号登录"
- Submitting state (spinner + disabled button)
- Error state: "登录未完成" inline message
- Tertiary text link → PG-002 (lowest visual weight)
- Clicking login → simulate 1.5s delay → redirect to PG-003

### PG-002 Break-glass Login
- Username + password form; submit button
- Warning text "不用于日常调查" (prominent, not dismissible)
- Error state: generic "凭证错误，请重试"
- Back link to PG-001
- Success → PG-003 with break-glass banner active

### PG-003 Alert List
- Left nav visible (role-aware: dev sees only "告警"; SRE sees "告警 / 扫描 / 设置")
- Filter bar: cluster dropdown + status toggle (firing / resolved / all)
- Table: status badge, alertname, cluster_id, team/namespace/unscoped badge, received time
- `unscoped` rows hidden from dev role (IX-PERM-02/05)
- LLM banner (if disabled) overlaid on Default state
- States: Default, Loading (skeleton), Empty, No Result (clear filter CTA), Error (retry)
- Row click → PG-005

### PG-004 Deep Link Miss
- Fixed main text: "尚未收到 AM webhook"
- Read-only display of cluster_id + fingerprint from URL params
- Link back to PG-003
- Error variant: "链接不完整" when params missing
- No Permission variant when alert exists but user can't see it

### PG-005 Alert Detail
- Two-panel at 1440px: left = alert info (L1/L2), right = investigation history + RelatedLinks
- Status badge (firing/resolved), alertname, cluster_id, labels, fingerprint (JetBrains Mono, copy button)
- "调查" button: triggers ConfirmModal (IX-CNF-01) → creates investigation → navigate to PG-006
- Quota counter: "今日剩余调查次数: N/30"
- Disabled + reason when quota=0 or org gate closed (IX-PERM-04)
- Investigation history list with status badges (linked to PG-006)
- RelatedLink section: "添加链接" → inline URL form → save (EX-08 validation)
- Write "看过" silently on mount (no toast per IX-FB-06)
- Mobile 375px: single column, "调查" sticky bottom

### PG-006 Investigation Detail
- L1: Status badge (running/completed/inconclusive) — three distinct color + text combos
- Skill load banner: "已加载组织约束" or "未加载组织约束" (BR-038)
- Cost gate counters: LLM n/8, 工具 n/12, 墙钟 elapsed/150s
- `running` state: animated tool call timeline (kube get/describe, PromQL), auto-transitions to terminal state after 4s (prototype simulation)
- `completed`: Claim list each with Citation chips; click Citation → slide-out ToolCall副本 panel; main title "调查完成"
- `inconclusive`: main title must NOT say "根因是…"; shows reason (zero citations / cost gate hit); tool failures labeled as failed, not clickable as citations
- RelatedLinks from alert: labeled "外部链接，不是证据"
- No editing affordance anywhere (BR-031)
- EX-06.8: expired investigation → "调查已按保留策略删除"

### PG-007 Cluster Scan (SRE only)
- No Permission state if dev role accesses via URL (IX-PERM-06)
- Cluster selector dropdown (from registered ClusterSources)
- "分析该集群" button → ConfirmModal (IX-CNF-02) → ScanRun=running
- Running: button disabled, row shows "running" status (IX-DUP-03)
- History table: time, cluster, status, link to PG-008
- No namespace filter control (EX-07.4)

### PG-008 Scan Result
- Header: cluster, ScanRun status badge, finding count
- Finding list: rule name (CrashLoop/ImagePull/etc.), affected resource, severity text
- Empty state: scan succeeded, 0 findings (distinct from scan_failed)
- scan_failed: error state with retry (new ScanRun)
- No ack/close controls (BR-027)
- No "auto-open investigation" link

### PG-009 Data Sources (SRE only)
- ClusterSource list: cluster_id, AM webhook status, Prom status, analyzer enabled toggle
- "注册集群" button (disabled + tooltip when count=5, EX-09.3)
- Registration form: cluster_id, AM webhook URL, Prom URL; no kubeconfig upload field (EX-09.4)
- Credential display: "已配置 / 重新生成" only, no plaintext (BR-052)
- IngestCredential note: "接入凭证与账号 OIDC 分离" (BR-016)

### PG-010 Skill Mapping (SRE only)
- Current mappings table: scope (全局/集群/team), Git repo URL
- Edit form: scope selector + Git URL field (optional, EX-09 pattern)
- Note: "空仓库允许上线；调查时将提示未加载组织约束"
- No inline SKILL.md editor

### PG-011 Team Bindings (SRE only)
- Mapping table: IdP group → label type (team/owner/namespace) → value
- Add/Edit row → ConfirmModal (IX-CNF-05)
- No "join team" self-service for users (IX-PERM-01)
- Note about namespace fallback (BR-013)
- Recent audit hint (read-only, no full audit search UI)

### PG-012 Quota & Cost Gate (SRE only)
- User quota section: user selector + "临时放行" → ConfirmModal (IX-CNF-03)
- TBD-BIZ text in confirmation: "临时放行（具体额度与时限待业务确认）"
- Org gate: "关闭新调查" toggle → ConfirmModal (IX-CNF-04); when on → all "调查" buttons across app become disabled
- Token gate input: number field or empty; empty displays "闸未配置，不得视为无限" (BR-042); never shows "无限制"

---

## Core Flows to Verify (Self-Check)

1. **TF-01**: PG-001 → (1.5s) → PG-003 ✓
2. **TF-02**: PG-001 → PG-002 → (success) → PG-003 with break-glass banner ✓
3. **TF-03**: Deep link → PG-001 → PG-005 → PG-006 ✓
4. **TF-05**: PG-005 "调查" → confirm → PG-006 running → completed/inconclusive ✓
5. **TF-07**: PG-007 select cluster → confirm → running → PG-008 ✓

## Role Demo via DevToolbar

| Toggle | Effect |
|---|---|
| Role: Dev | Nav hides Scan/Settings; unscoped alerts hidden; no scan/settings access |
| Role: SRE | Full nav; sees all alerts |
| Role: break-glass | Full nav + persistent banner |
| LLM: off | LLM banner on PG-003/PG-005; investigation button still shows (TBD-BIZ handled per EX-05.6) |
| Org gate: closed | All "调查" buttons disabled with reason |

---

## Key Constraints Honored

- No silence/ack/page/IM/kubectl buttons anywhere (IX-PERM-08: not rendered, not grayed)
- `inconclusive` title never says "根因是…"
- `unscoped` hidden from dev (not grayed — invisible)
- Citation cannot be edited or added by user
- No kubeconfig upload field
- org token gate empty → "未配置" not "无限"
- No "申请放行" button on quota error
- RelatedLinks labeled "外部链接，不是证据" in PG-006

---

## Implementation Order

1. `src/index.css` — Google Fonts imports + design tokens (dark slate palette)
2. `src/mock/` — all mock data
3. `src/App.tsx` — AppContext + Router with all 12 routes + DevToolbar
4. `AppShell` + shared components (StatusBadge, ConfirmModal, LLMBanner, BreakGlassBanner)
5. PG-001, PG-002 (auth entry points)
6. PG-003 → PG-005 → PG-006 (core investigation flow)
7. PG-004 (deep link miss)
8. PG-007, PG-008 (scan flow)
9. PG-009 → PG-012 (settings)

## Verification

- Walk TF-01 → TF-05 → TF-06 (completed path) without DevTools intervention
- Switch to Dev role in DevToolbar: confirm Scan/Settings nav gone, unscoped rows gone, PG-007 URL → No Permission
- Switch org gate off: confirm PG-005 "调查" button disabled with reason
- Visit PG-004 with a fingerprint URL param: confirm "尚未收到 AM webhook" copy
- Check PG-006 inconclusive state: confirm no "根因是…" in any heading
- Check PG-012 empty token field: confirm "闸未配置，不得视为无限" displayed
